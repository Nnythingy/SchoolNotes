from flask import *
 
app = Flask(__name__)
 
@app.route('/')
def index():
    accountname = request.args.get('accountname', '')
    
    if accountname:
        return render_template_string('Hi ' + accountname + '!')
    else:
        hint = "<p>Missing something? Maybe there is a hidden parameter in this page...</p>"
        return render_template_string(hint) 

# main driver function
if __name__ == "__main__":
    app.run()
