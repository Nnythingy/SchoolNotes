# How to set up this machine?

0. Ensure that you have docker installed
1. Build the docker image: `sudo docker build -t unfiltered .`
2. Run the docker container: `sudo docker run -p 8000:8000 unfiltered`
3. Access the vulnerable webpage at http://127.0.0.1:8000
