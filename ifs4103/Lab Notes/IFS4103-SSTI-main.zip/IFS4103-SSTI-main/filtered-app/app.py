from flask import *
import re

app = Flask(__name__)

sensitive_keywords = ['.', '[', ']', '_', '__', '{{', '}}', '"', 'os', 'modules']
sensitive_pattern = re.compile('|'.join(map(re.escape, sensitive_keywords)))

insensitive_keywords = ['base', 'import', 'application', 'builtins']
insensitive_pattern = [re.compile(re.escape(keyword), re.IGNORECASE) for keyword in insensitive_keywords]

@app.route('/')
def index():
    accountname = request.args.get('accountname', '')
    
    if accountname:
        while True:    
            oldaccountname = accountname
            accountname = sensitive_pattern.sub('', accountname)
            for pattern in insensitive_pattern:
                accountname = pattern.sub('', accountname)
            if oldaccountname == accountname:
                break
        return render_template_string('Hi ' + accountname + '!')
    else:
        hint = "<p>Missing something? Maybe there is a hidden parameter in this page...</p>"
        return render_template_string(hint) 

# main driver function
if __name__ == "__main__":
    app.run()
