apt-get install python-pip
pip install requests