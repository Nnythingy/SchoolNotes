/*************************************
* Lab 1 Exercise 3
* Name:
* Student No:
* Lab Group:
*************************************/

#include "functions.h"

// Replace the below with your own initialization
// - again this is just an example!
int (*func_list[6])(int) = {
    add_one,
    add_two,
    multiply_five,
    square,
    cube,
    add_five};

void update_functions() {
}
