/*
    You can modify this file for your testing purpose but note
    that we will use our own copies of this file for testing
    during grading so any changes in this file will be overwritten
*/

// What does extern do? Feel free to find out more about it!
extern int (*func_list[5])(int x);

void update_functions();
