// This program decides if the output file produced by the ex4 grader is an acceptable output.
// This program prints two lines of output:
// The first line is '1' if correct and '0' if incorrect.
// The second line is a human-readable explanation.
// If the input or grader output has issues (probably not caused by the student),
// this program will print the error to stderr, and will not write anything to stdout, and will exit with code 1.

#include <algorithm>
#include <exception>
#include <fstream>
#include <iostream>
#include <list>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#if EXERCISE == 6
#include <cassert>
#endif
using namespace std;

// Ex4 things to validate at every period:
// - Every group that gets seated is seated on an empty table with the same number of seats (assuming all leaves happen before seateds)
// - No group in the queue overtakes some earlier group of the same size (all the groups entering in the same period are given the same enqueue time)
// - There cannot be queueing groups and empty tables of the same size

// Ex5 things to validate at every period:
// - Every group that gets seated is seated on an empty table with enough seats (assuming all leaves happen before seateds)
// - No group in the queue overtakes some earlier group of size less than or equal to this group
// - For each X, there cannot be queueing groups of size X and empty tables of size >= X
// - The actual table assignment must be "lower" or equal to the version where all the leaves occured after all the moves

// Ex6 things to validate at every period:
// - Exponential time simulation grading - seems like no way around it

// An error that is probably our fault.
struct testcase_error : public std::runtime_error {
    testcase_error(const std::string& what_arg)
        : std::runtime_error(what_arg)
    {
    }
    testcase_error(const char* what_arg)
        : std::runtime_error(what_arg)
    {
    }
};

// An error that is probably the student's fault.
struct implementation_error : public std::runtime_error {
    implementation_error(const std::string& what_arg)
        : std::runtime_error(what_arg)
    {
    }
    implementation_error(const char* what_arg)
        : std::runtime_error(what_arg)
    {
    }
};

// Simulates the restaurant.
// All functions apart from the constructor will throw an exception if the student code has errors.
// input events will come before output events in the same period.
class simulator {
private:
    struct queueitem;
    struct queuewrap;
    struct group {
        int group_size;
        list<queueitem>::iterator queue_it; // is end() if not in queue
        int table_id; // is -1 if not seated
        group(const group&) = delete;
        group& operator=(const group&) = delete;
        group(int size, queuewrap& queuew)
            : group_size(size)
            , queue_it(queuew.enqueue(*this))
            , table_id(-1)
        {
        }
    };
    struct queueitem {
        group& grp;
        int enter_time;
    };
    struct table {
        int table_size;
        int num_empty_seats;
    };
    class queuewrap {
    private:
        list<queueitem> queue;
        int last_time = 0;
        int count_in_queue[5] = {};

    public:
        list<queueitem>::iterator enqueue(group& grp)
        {
            ++count_in_queue[grp.group_size - 1];
            queue.push_back(queueitem { grp, last_time });
            return --queue.end();
        }
        int dequeue(list<queueitem>::iterator it)
        {
            if (it == queue.end()) {
                throw testcase_error("Trying to seat a group that is not in queue");
            }
            --count_in_queue[it->grp.group_size - 1];
            int time = it->enter_time;
            queue.erase(it);
            return time;
        }
        void checkcommit(int* max_dequeue_time, int* count_empty_tables)
        {
#if EXERCISE == 4
            for (int i = 0; i < 5; ++i) {
                for (auto queue_it = queue.begin(); queue_it == queue.end() && queue_it->enter_time < max_dequeue_time[i]; ++queue_it) {
                    if (queue_it->grp.group_size == i + 1) {
                        throw implementation_error("A later group was seated even though an earlier group that could be seated was not seated");
                    }
                }
            }
            for (int i = 0; i < 5; ++i) {
                if (count_in_queue[i] > 0 && count_empty_tables[i] > 0) {
                    throw implementation_error("A group could be seated but was not seated");
                }
            }
#elif EXERCISE == 5
            for (int i = 0; i < 5; ++i) {
                for (auto queue_it = queue.begin(); queue_it == queue.end() && queue_it->enter_time < max_dequeue_time[i]; ++queue_it) {
                    if (queue_it->grp.group_size <= i + 1) {
                        throw implementation_error("A later group was seated even though an earlier group that could be seated was not seated");
                    }
                }
            }
            int sum = 0;
            for (int i = 4; i >= 0; --i) {
                sum += count_empty_tables[i];
                if (count_in_queue[i] > 0 && sum > 0) {
                    throw implementation_error("A group could be seated but was not seated");
                }
            }
#elif EXERCISE == 6
            for (int i = 0; i < 5; ++i) {
                for (auto queue_it = queue.begin(); queue_it == queue.end() && queue_it->enter_time < max_dequeue_time[i]; ++queue_it) {
                    if (queue_it->grp.group_size <= i + 1) {
                        throw implementation_error("A later group was seated even though an earlier group that could be seated was not seated");
                    }
                }
            }
            int sum = 0;
            for (int i = 4; i >= 0; --i) {
                sum += count_empty_tables[i];
                if (count_in_queue[i] > 0 && sum > 0) {
                    throw implementation_error("A group could be seated but was not seated");
                }
            }
#else
            static_assert(false);
#endif
            ++last_time;
        }
    };
    queuewrap queuew;
    unordered_map<int, group> groups; // map from group id to group
    vector<table> tables;
    int max_dequeue_time[5];
    int count_empty_tables[5];
#if EXERCISE == 5
    int lateleave_count_empty_tables[5];
    int delayed_leaves[5];
#elif EXERCISE == 6
    enum struct command_type {
        SEATED,
        LEAVE
    };
    struct command {
        //command_type type;
        int group_id;
        int group_size;
        int table_id;
    };
    /*struct command_cmp {
        // The order of leaves do not matter
        bool operator()(const command& a, const command& b) const
        {
            if (a.type != b.type)
                return a.type < b.type;
            if (a.group_id != b.group_id)
                return a.group_id < b.group_id;
            if (a.group_size != b.group_size)
                return a.group_size < b.group_size;
            return a.table_id < b.table_id;
        }
    };*/
    vector<command> seated_cmds, leave_cmds;
    vector<table> cloned_tables;
#endif

public:
    simulator(int* num_tables)
    {
        int sum = 0;
        for (int i = 0; i < 5; ++i)
            sum += num_tables[i];
        for (int i = 0; i < 5; ++i)
            count_empty_tables[i] = num_tables[i];
#if EXERCISE == 5
        for (int i = 0; i < 5; ++i)
            lateleave_count_empty_tables[i] = count_empty_tables[i];
        for (int i = 0; i < 5; ++i)
            delayed_leaves[i] = 0;
#endif
        for (int i = 0; i < 5; ++i)
            max_dequeue_time[i] = 0;
        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < num_tables[i]; ++j) {
                tables.push_back({ i + 1, i + 1 });
            }
        }
#if EXERCISE == 6
        cloned_tables = tables;
#endif
    }
    void input_enter(int group_id, int group_size)
    {
        if (!groups.try_emplace(group_id, group_size, queuew).second) {
            throw testcase_error("Duplicate group ID in input file");
        }
    }
    void input_leave(int group_id)
    {
        if (auto group_it = groups.find(group_id); group_it != groups.end()) {
            group& group = group_it->second;
            if (group.table_id < 0 || group.table_id >= static_cast<int>(tables.size())) {
                throw testcase_error("Tried to make a group leave when it is not already seated");
            }
#if EXERCISE == 6
            leave_cmds.push_back({ group_id, group.group_size, group.table_id });
#endif
            tables[group.table_id].num_empty_seats += group.group_size;
            if (tables[group.table_id].num_empty_seats == tables[group.table_id].table_size) {
                ++count_empty_tables[tables[group.table_id].table_size - 1];
#if EXERCISE == 5
                ++delayed_leaves[tables[group.table_id].table_size - 1];
#endif
            }
            group.table_id = -1;
        } else {
            throw testcase_error("Trying to make an invalid group leave");
        }
    }
    void output_seated(int group_id, int table_id)
    {
        if (auto group_it = groups.find(group_id); group_it != groups.end()) {
            group& group = group_it->second;
            int enter_time = queuew.dequeue(group.queue_it);
            max_dequeue_time[group.group_size - 1] = max(max_dequeue_time[group.group_size - 1], enter_time);
            if (table_id < 0 || table_id >= static_cast<int>(tables.size())) {
                throw implementation_error("Tried to seat a group at a nonexistent table");
            }
#if EXERCISE == 4
            if (tables[table_id].table_size != group.group_size) {
                throw implementation_error("Tried to seat a group at a table of incorrect size");
            }
            if (tables[table_id].table_size != tables[table_id].num_empty_seats) {
                throw implementation_error("Tried to seat a group at a table that is not empty");
            }
#elif EXERCISE == 5
            if (tables[table_id].table_size < group.group_size) {
                throw implementation_error("Tried to seat a group at a table of smaller size");
            }
            if (tables[table_id].table_size != tables[table_id].num_empty_seats) {
                throw implementation_error("Tried to seat a group at a table that is not empty");
            }
#elif EXERCISE == 6
            if (tables[table_id].num_empty_seats < group.group_size) {
                throw implementation_error("Tried to seat a group at a table with insufficiently many empty seats");
            }
            seated_cmds.push_back({ group_id, group.group_size, table_id });
#else
            static_assert(false);
#endif
            if (tables[table_id].num_empty_seats == tables[table_id].table_size) {
                --count_empty_tables[tables[table_id].table_size - 1];
            }
            tables[table_id].num_empty_seats -= group.group_size;
            group.table_id = table_id;
#if EXERCISE == 5
            for (int i = group.group_size; i <= 5; ++i) {
                if (lateleave_count_empty_tables[i - 1] > 0) {
                    --lateleave_count_empty_tables[i - 1];
                    break;
                }
            }
#endif
        } else {
            throw testcase_error("Trying to seat an invalid group");
        }
    }
    void separate()
    {
#if EXERCISE == 5
        for (int i = 0; i < 5; ++i) {
            lateleave_count_empty_tables[i] += delayed_leaves[i];
        }
        int cumreal = 0, cumworst = 0;
        for (int i = 0; i < 5; ++i) {
            cumreal += count_empty_tables[i];
            cumworst += lateleave_count_empty_tables[i];
            if (cumreal > cumworst) {
                throw implementation_error("A group was seated on a larger table when there was an empty smaller table that was also large enough");
            }
        }
#elif EXERCISE == 6
        // Do exponential-time simulation
        bruteforce_validate();
#endif
        queuew.checkcommit(max_dequeue_time, count_empty_tables);
#if EXERCISE == 5
        for (int i = 0; i < 5; ++i)
            lateleave_count_empty_tables[i] = count_empty_tables[i];
        for (int i = 0; i < 5; ++i)
            delayed_leaves[i] = 0;
#elif EXERCISE == 6
        seated_cmds.clear();
        leave_cmds.clear();
        cloned_tables = tables;
#endif
    }
#if EXERCISE == 6
    static void push_leave(const command& cmd, table* cloned_tables, int* num_nonempty_tables, int* num_empty_tables) {
        table& tbl = cloned_tables[cmd.table_id];
        if (tbl.num_empty_seats > 0) {
            --num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        tbl.num_empty_seats += cmd.group_size;
        assert(tbl.num_empty_seats <= tbl.table_size);
        if (tbl.num_empty_seats == tbl.table_size) {
            ++num_empty_tables[tbl.num_empty_seats - 1];
        } else {
            ++num_nonempty_tables[tbl.num_empty_seats - 1];
        }
    }
    static void pop_leave(const command& cmd, table* cloned_tables, int* num_nonempty_tables, int* num_empty_tables) {
        table& tbl = cloned_tables[cmd.table_id];
        if (tbl.num_empty_seats == tbl.table_size) {
            --num_empty_tables[tbl.num_empty_seats - 1];
        } else {
            --num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        tbl.num_empty_seats -= cmd.group_size;
        if (tbl.num_empty_seats > 0) {
            ++num_nonempty_tables[tbl.num_empty_seats - 1];
        }
    }
    static bool push_seated(const command& cmd, table* cloned_tables, int* num_nonempty_tables, int* num_empty_tables) {
        table& tbl = cloned_tables[cmd.table_id];
        // check if this table is ideal for this group
        const bool is_empty = tbl.num_empty_seats == tbl.table_size;
        if (is_empty) {
            for (int i = cmd.group_size; i < tbl.num_empty_seats; ++i) {
                if (num_empty_tables[i - 1] > 0) {
                    return false;
                }
            }
        } else {
            for (int i = cmd.group_size; i <= 5; ++i) {
                if (num_empty_tables[i - 1] > 0) {
                    return false;
                }
            }
            for (int i = cmd.group_size; i < tbl.num_empty_seats; ++i) {
                if (num_nonempty_tables[i - 1] > 0) {
                    return false;
                }
            }
        }
        if (tbl.num_empty_seats < cmd.group_size) {
            return false;
        }
        if (is_empty) {
            --num_empty_tables[tbl.num_empty_seats - 1];
        } else {
            --num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        tbl.num_empty_seats -= cmd.group_size;
        if (tbl.num_empty_seats > 0) {
            ++num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        return true;
    }
    static void pop_seated(const command& cmd, table* cloned_tables, int* num_nonempty_tables, int* num_empty_tables) {
        table& tbl = cloned_tables[cmd.table_id];
        if (tbl.num_empty_seats > 0) {
            --num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        tbl.num_empty_seats += cmd.group_size;
        const bool is_empty = tbl.num_empty_seats == tbl.table_size;
        if (is_empty) {
            ++num_empty_tables[tbl.num_empty_seats - 1];
        } else {
            ++num_nonempty_tables[tbl.num_empty_seats - 1];
        }
        
    }
    template <typename SeatedIt, typename LeaveIt>
    static bool dfs(SeatedIt seated_begin, SeatedIt seated_end, LeaveIt leave_begin, LeaveIt leave_mid, LeaveIt leave_end, table* cloned_tables, int* num_nonempty_tables, int* num_empty_tables) {
        if (seated_begin == seated_end) return true;
        for(auto seated_it = seated_begin; seated_it != seated_end; ++seated_it) {
            if(push_seated(*seated_it, cloned_tables, num_nonempty_tables, num_empty_tables)) {
                iter_swap(seated_begin, seated_it);
                if (dfs(seated_begin + 1, seated_end, leave_begin, leave_begin, leave_end, cloned_tables, num_nonempty_tables, num_empty_tables)) {
                    return true;
                }
                iter_swap(seated_begin, seated_it);
                pop_seated(*seated_it, cloned_tables, num_nonempty_tables, num_empty_tables);
            }
        }
        for (auto leave_it = leave_mid; leave_it != leave_end; ++leave_it) {
            push_leave(*leave_it, cloned_tables, num_nonempty_tables, num_empty_tables);
            iter_swap(leave_begin, leave_it);
            if (dfs(seated_begin, seated_end, leave_begin + 1, leave_it + 1, leave_end, cloned_tables, num_nonempty_tables, num_empty_tables)) {
                return true;
            }
            iter_swap(leave_begin, leave_it);
            pop_leave(*leave_it, cloned_tables, num_nonempty_tables, num_empty_tables);
        }
        return false;
    }
    void bruteforce_validate()
    {
        //sort(curr_cmds.begin(), curr_cmds.end(), command_cmp {});
        int num_nonempty_tables[5] = { 0 };
        int num_empty_tables[5] = { 0 };
        for (const table& tbl : cloned_tables) {
            if (tbl.num_empty_seats > 0) {
                if (tbl.table_size == tbl.num_empty_seats) {
                    ++num_empty_tables[tbl.num_empty_seats - 1];
                } else {
                    ++num_nonempty_tables[tbl.num_empty_seats - 1];
                }
            }
        }
        cerr << "======================" << endl;
        cerr << "Old:" << endl;
        for (const table& tbl : cloned_tables) {
            cerr << (&tbl - cloned_tables.data()) << ' ' << tbl.table_size << ' ' << tbl.num_empty_seats << endl;
        }
        /*cerr << "Delta:" << endl;
        for (const command& cmd : curr_cmds) {
            cerr << (int)cmd.type << ' ' << cmd.group_id << ' ' << cmd.group_size << ' ' << cmd.table_id << endl;
        }*/
        cerr << "New:" << endl;
        for (const table& tbl : tables) {
            cerr << (&tbl - tables.data()) << ' ' << tbl.table_size << ' ' << tbl.num_empty_seats << endl;
        }
        if (dfs(seated_cmds.begin(), seated_cmds.end(), leave_cmds.begin(), leave_cmds.begin(), leave_cmds.end(), cloned_tables.data(), num_nonempty_tables, num_empty_tables)) {
            return;
        }
        throw implementation_error("The assignment of groups to tables does not have any viable ordering of commands");
    }
#endif
};

int main(int argc, char** argv)
try {
    if (argc != 3) {
        cerr << "Usage: ./ex4_checker <input_file> <grader_output_file>\n";
        return 1;
    }
    ios_base::sync_with_stdio(false);
    ifstream input_file(argv[1]);
    ifstream grader_output_file(argv[2]);

    int num_tables[5];
    for (int i = 0; i < 5; ++i) {
        input_file >> num_tables[i];
    }

    simulator sim(num_tables);

    while (true) {
        while (true) {
            string type;
            input_file >> type;
            if (!input_file || type == ".")
                break;
            else if (type == "Enter") {
                int group_id, group_size;
                input_file >> group_id >> group_size;
                sim.input_enter(group_id, group_size);
            } else if (type == "Leave") {
                int group_id;
                input_file >> group_id;
                sim.input_leave(group_id);
            } else {
                cerr << "Input file error\n";
                return 1;
            }
        }
        while (true) {
            string type;
            grader_output_file >> type;
            if (!grader_output_file || type == ".")
                break;
            else if (type == "A") {
                cerr << "Input file adaptiveness error\n";
                return 1;
            } else if (type == "B") {
                cout << "0\nSome group called on_enqueue() twice\n";
                return 0;
            } else if (type == "C") {
                cout << "0\nA group could be seated but was not seated (timeout)\n";
                return 0;
            } else if (type == "D") {
                cout << "0\non_enqueue() was not called for some group (timeout)\n";
                return 0;
            } else if (type == "E") {
                cout << "0\nleave_table() seems to be blocked (timeout)\n";
                return 0;
            } else if (type == "Seated") {
                int group_id, table_id;
                grader_output_file >> group_id >> table_id;
                sim.output_seated(group_id, table_id);
            } else {
                cerr << "Grader output file error\n";
                return 1;
            }
        }
        sim.separate();
        if (!input_file)
            break;
    }
    cout << "1\n\n";
    return 0;
} catch (const implementation_error& e) {
    cout << "0\n"
         << e.what() << '\n';
    return 0;
} catch (const testcase_error& e) {
    cerr << e.what() << '\n';
    return 1;
}