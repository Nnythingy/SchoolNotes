// This program decides if the output file produced by the ex1 grader is an acceptable output.
// This program prints two lines of output:
// The first line is '1' if correct and '0' if incorrect.
// The second line is a human-readable explanation.
// If the input or grader output has issues (probably not caused by the student),
// this program will print the error to stderr, and will not write anything to stdout, and will exit with code 1.

#include <algorithm>
#include <iostream>
#include <fstream>
#include <set>
#include <string>
#include <optional>
#include <vector>
#include <utility>
using namespace std;

bool same_unordered(pair<int, int> a, pair<int, int> b) {
    if (a.second < a.first) swap(a.first, a.second);
    if (b.second < b.first) swap(b.first, b.second);
    return a == b;
}

bool less_unordered(pair<int, int> a, pair<int, int> b) {
    if (a.second < a.first) swap(a.first, a.second);
    if (b.second < b.first) swap(b.first, b.second);
    return a < b;
}

int main(int argc, char** argv) {
    if (argc != 3) {
        cerr << "Usage: ./ex1_checker <input_file> <grader_output_file>\n";
        return 1;
    }
    ios_base::sync_with_stdio(false);
    ifstream input_file(argv[1]);
    ifstream grader_output_file(argv[2]);
    optional<int> prevstore[3];
    int balls_per_pack;
    input_file >> balls_per_pack;
    if (balls_per_pack != 2) {
        cerr << "Input file error\n";
        return 1;
    }
    while (true) {
        multiset<int> inputs[3];
        vector<pair<int, int>> grader_outputs[3];
        while (true) {
            char ch;
            input_file >> ch;
            if (!input_file || ch =='.') break;
            if (ch < '1' || ch > '3') {
                cerr << "Input file error\n";
                return 1;
            }
            int id;
            input_file >> id;
            if (!input_file) {
                cerr << "Input file error\n";
                return 1;
            }
            inputs[ch - '1'].insert(id);
        }
        while (true) {
            char ch;
            grader_output_file >> ch;
            if (!grader_output_file || ch == '.') break;
            if (ch == 'A') {
                cout << "0\nA group of balls can be packed but was not packed\n";
                return 0;
            }
            if (ch < '1' || ch > '3') {
                cerr << "Grader output file error\n";
                return 1;
            }
            int my_id, other_id;
            grader_output_file >> my_id >> other_id;
            if (!grader_output_file) {
                cerr << "Grader output file error\n";
                return 1;
            }
            grader_outputs[ch - '1'].emplace_back(my_id, other_id);
        }
        for (int i = 0; i < 3; ++i) {
            sort(grader_outputs[i].begin(), grader_outputs[i].end(), [](const pair<int, int>& a, const pair<int, int>& b){
                return less_unordered(a, b);
            });
            for (auto it = grader_outputs[i].begin(); it != grader_outputs[i].end(); it += 2) {
                if (prevstore[i] == it->first) {
                    prevstore[i] = nullopt;
                }
                else if (auto inputs_it = inputs[i].find(it->first); inputs_it != inputs[i].end()) {
                    inputs[i].erase(inputs_it);
                }
                else {
                    cerr << "Grader output file error: The ball with specified id and colour does not exist\n";
                    return 1;
                }
                if (prevstore[i] == it->second) {
                    prevstore[i] = nullopt;
                }
                else if (auto inputs_it = inputs[i].find(it->second); inputs_it != inputs[i].end()) {
                    inputs[i].erase(inputs_it);
                }
                else {
                    for (int j = 0; j < 3; ++j) {
                        if (prevstore[j] == it->second) {
                            cout << "0\nBall was matched to another ball of different colour\n";
                            return 0;
                        }
                        if (auto inputs_it = inputs[j].find(it->second); inputs_it != inputs[j].end()) {
                            cout << "0\nBall was matched to another ball of different colour\n";
                            return 0;
                        }
                    }
                    cout << "0\nRequested ball to be packed with does not exist or was already packed earlier\n";
                    return 0;
                }
                if (it + 1 == grader_outputs[i].end() || !same_unordered(*it, *(it + 1))) {
                    cout << "0\nDid not receive both balls in pair\n";
                    return 0;
                }
            }
            if (!grader_outputs[i].empty() && prevstore[i]) {
                cout << "0\nA ball was packed even though there are unpacked balls of the same colour that arrived earlier than it\n";
                return 0;
            }
        }
        for (int i = 0; i < 3; ++i) {
            if (prevstore[i]) {
                if (!inputs[i].empty()) {
                    cout << "0\nA pair of balls can be packed but was not packed\n";
                    return 0;
                }
            }
            else {
                if (inputs[i].size() > 1) {
                    cout << "0\nA pair of balls can be packed but was not packed\n";
                    return 0;
                }
                else if (inputs[i].size() == 1) {
                    prevstore[i] = *(inputs[i].begin());
                }
            }
        }
        if (!input_file && grader_output_file) {
            cerr << "Input file ended before grader output file\n";
            return 1;
        }
        if (input_file && !grader_output_file) {
            cerr << "Grader output file ended before input file\n";
            return 1;
        }
        if (!input_file) break;
    }
    cout << "1\n\n";
    return 0;
}