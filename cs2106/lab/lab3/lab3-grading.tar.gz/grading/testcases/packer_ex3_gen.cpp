// Test case generator for ex2 and ex3

#include <random>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <cassert>

using namespace std;

struct Command {
    int color;
    int id;
};

template <typename URBG>
int assign_unique_id(URBG&& rng, set<int>& ids) {
    while (true) {
        // we will be nice and only test ids in [1, 1000000].
        int id = uniform_int_distribution<int>(1, 1000000)(rng);
        if (ids.emplace(id).second) {
            return id;
        }
    }
}

// parallelism is the ratio of number of commands to number of '.'s.  If parallelism==1 then this will be a sequential test
template <typename URBG, typename String>
void generate_test_case(URBG&& rng, String&& name, int balls_per_pack, int num_commands, int parallelism) {
    ofstream out(name);
    out << balls_per_pack << '\n';
    vector<Command> commands;
    set<int> ids;
    num_commands /= balls_per_pack;
    for (int i = 0; i < num_commands; ++i) {
        int color = uniform_int_distribution<int>(1, 3)(rng);
        for (int j = 0; j < balls_per_pack; ++j) {
            int id = assign_unique_id(rng, ids);
            commands.push_back({color, id});
        }
    }
    shuffle(commands.begin(), commands.end(), rng);
    assert(!commands.empty());
    vector<bool> spaces;
    int num_spaces = num_commands * balls_per_pack - 1;
    int num_separators = num_spaces / parallelism;
    for (int i = 0; i < num_separators; ++i) {
        spaces.push_back(true);
    }
    for (int i = num_separators; i < num_spaces; ++i) {
        spaces.push_back(false);
    }
    shuffle(spaces.begin(), spaces.end(), rng);
    assert(spaces.size() + 1 == commands.size());
    auto commands_it = commands.begin();
    out << commands_it->color << ' ' << commands_it->id << '\n';
    ++commands_it;
    for (auto spaces_it = spaces.begin(); spaces_it != spaces.end(); ++spaces_it, ++commands_it) {
        if (*spaces_it) {
            out << ".\n";
        }
        out << commands_it->color << ' ' << commands_it->id << '\n';
    }
}

int main() {
    mt19937_64 rng(0x92d3aa7c70c7e963u);

    /* Ex2 test cases */
    generate_test_case(rng, "ex2/seq_random_small_1.in", 2, 30, 1);
    generate_test_case(rng, "ex2/seq_random_small_2.in", 2, 30, 1);
    generate_test_case(rng, "ex2/seq_random_small_3.in", 2, 30, 1);
    generate_test_case(rng, "ex2/seq_random_small_4.in", 2, 30, 1);
    generate_test_case(rng, "ex2/seq_random_small_5.in", 2, 30, 1);
    generate_test_case(rng, "ex2/seq_random_large_1.in", 2, 100, 1);
    generate_test_case(rng, "ex2/seq_random_large_2.in", 2, 100, 1);
    generate_test_case(rng, "ex2/par_random_small_1.in", 2, 30, 2);
    generate_test_case(rng, "ex2/par_random_small_2.in", 2, 30, 4);
    generate_test_case(rng, "ex2/par_random_small_3.in", 2, 30, 6);
    generate_test_case(rng, "ex2/par_random_small_4.in", 2, 30, 8);
    generate_test_case(rng, "ex2/par_random_small_5.in", 2, 30, 10);
    generate_test_case(rng, "ex2/par_random_large_1.in", 2, 100, 2);
    generate_test_case(rng, "ex2/par_random_large_2.in", 2, 100, 10);
    generate_test_case(rng, "ex2/par_random_large_3.in", 2, 100, 120);

    /* Ex3 test cases */
    generate_test_case(rng, "ex3/seq_random_small_1.in", 3, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_2.in", 5, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_3.in", 6, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_4.in", 10, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_5.in", 15, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_6.in", 3, 30, 1);
    generate_test_case(rng, "ex3/seq_random_small_7.in", 10, 30, 1);
    generate_test_case(rng, "ex3/seq_random_large_1.in", 3, 100, 1);
    generate_test_case(rng, "ex3/seq_random_large_2.in", 4, 100, 1);
    generate_test_case(rng, "ex3/seq_random_large_3.in", 20, 100, 1);
    generate_test_case(rng, "ex3/seq_random_large_4.in", 25, 100, 1);
    generate_test_case(rng, "ex3/par_random_small_1.in", 5, 30, 2);
    generate_test_case(rng, "ex3/par_random_small_2.in", 5, 30, 4);
    generate_test_case(rng, "ex3/par_random_small_3.in", 5, 30, 6);
    generate_test_case(rng, "ex3/par_random_small_4.in", 5, 30, 8);
    generate_test_case(rng, "ex3/par_random_small_5.in", 5, 30, 10);
    generate_test_case(rng, "ex3/par_random_small_6.in", 15, 30, 10);
    generate_test_case(rng, "ex3/par_random_small_7.in", 10, 30, 10);
    generate_test_case(rng, "ex3/par_random_small_8.in", 3, 30, 10);
    generate_test_case(rng, "ex3/par_random_small_9.in", 15, 30, 2);
    generate_test_case(rng, "ex3/par_random_small_10.in", 10, 30, 2);
    generate_test_case(rng, "ex3/par_random_small_11.in", 3, 30, 2);
    generate_test_case(rng, "ex3/par_random_large_1.in", 4, 100, 2);
    generate_test_case(rng, "ex3/par_random_large_2.in", 25, 100, 2);
    generate_test_case(rng, "ex3/par_random_large_3.in", 5, 100, 10);
    generate_test_case(rng, "ex3/par_random_large_4.in", 20, 100, 10);
    generate_test_case(rng, "ex3/par_random_large_5.in", 10, 100, 120);
}