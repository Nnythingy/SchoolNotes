// Test case generator for ex4-ex6

#include <random>
#include <fstream>

using namespace std;

// parallelism is the ratio of number of commands to number of '.'s.
template <typename URBG, typename String>
void generate_test_case(URBG&& rng, String&& name, int num_commands, int queue_target) {
    ofstream out(name);
    out << rng() << ' ' << rng() << ' ' << num_commands << ' '<< queue_target << '\n';
}

int main() {
    mt19937_64 rng(0x92d3aa7c70c7e963u);

    /* Ex4 test cases */
    generate_test_case(rng, "ex4/seq_random_1.in", 30, 15);
    generate_test_case(rng, "ex4/seq_random_2.in", 30, 30);
    generate_test_case(rng, "ex4/seq_random_3.in", 30, 45);
    generate_test_case(rng, "ex4/seq_random_4.in", 80, 15);
    generate_test_case(rng, "ex4/seq_random_5.in", 80, 30);
    generate_test_case(rng, "ex4/seq_random_6.in", 80, 45);
    generate_test_case(rng, "ex4/par_random_1.in", 30, 15);
    generate_test_case(rng, "ex4/par_random_2.in", 30, 30);
    generate_test_case(rng, "ex4/par_random_3.in", 30, 45);
    generate_test_case(rng, "ex4/par_random_4.in", 80, 15);
    generate_test_case(rng, "ex4/par_random_5.in", 80, 30);
    generate_test_case(rng, "ex4/par_random_6.in", 80, 45);
    generate_test_case(rng, "ex4/par_random_7.in", 80, 20);

    /* Ex5 test cases */
    generate_test_case(rng, "ex5/seq_random_1.in", 30, 15);
    generate_test_case(rng, "ex5/seq_random_2.in", 30, 30);
    generate_test_case(rng, "ex5/seq_random_3.in", 30, 45);
    generate_test_case(rng, "ex5/seq_random_4.in", 80, 15);
    generate_test_case(rng, "ex5/seq_random_5.in", 80, 30);
    generate_test_case(rng, "ex5/seq_random_6.in", 80, 45);
    generate_test_case(rng, "ex5/par_random_1.in", 30, 15);
    generate_test_case(rng, "ex5/par_random_2.in", 30, 30);
    generate_test_case(rng, "ex5/par_random_3.in", 30, 45);
    generate_test_case(rng, "ex5/par_random_4.in", 80, 15);
    generate_test_case(rng, "ex5/par_random_5.in", 80, 30);
    generate_test_case(rng, "ex5/par_random_6.in", 80, 45);
    generate_test_case(rng, "ex5/par_random_7.in", 80, 20);

    /* Ex6 test cases */
    generate_test_case(rng, "ex6/seq_random_1.in", 30, 15);
    generate_test_case(rng, "ex6/seq_random_2.in", 30, 30);
    generate_test_case(rng, "ex6/seq_random_3.in", 30, 45);
    generate_test_case(rng, "ex6/seq_random_4.in", 80, 15);
    generate_test_case(rng, "ex6/seq_random_5.in", 80, 30);
    generate_test_case(rng, "ex6/seq_random_6.in", 80, 45);
    generate_test_case(rng, "ex6/par_random_1.in", 30, 15);
    generate_test_case(rng, "ex6/par_random_2.in", 30, 30);
    generate_test_case(rng, "ex6/par_random_3.in", 30, 45);
    generate_test_case(rng, "ex6/par_random_4.in", 80, 15);
    generate_test_case(rng, "ex6/par_random_5.in", 80, 30);
    generate_test_case(rng, "ex6/par_random_6.in", 80, 45);
    generate_test_case(rng, "ex6/par_random_7.in", 80, 20);
}