# Main grading script
# Submissions should be put into SUBMISSION_DIR before running this script (see definition below)

import csv
import os
from itertools import chain
from typing import NamedTuple, Tuple, Optional, List, Callable
import subprocess
import re
import time
import concurrent.futures
import threading

EXEC_DIR: str = 'execute'
COMPILE_DIR: str = 'compile'
EXTRACT_DIR: str = 'extract'
SUBMISSION_DIR: str = '../submissions'
SKELETON_DIR: str = '../code'
GRADER_DIR: str = 'grader'
CHECKER_DIR: str = 'checker'
TESTCASE_DIR: str = 'testcases'

class TestCase(NamedTuple):
    name: str
    execute: Callable[[], Tuple[float, str]] # returns the score (between 0 and 1 inclusive) and a friendly message

class Exercise(NamedTuple):
    name: str
    compile: Callable[[], Optional[str]] # returns a string if compilation failed
    test_cases: List[TestCase]
    score: Callable[[List[Tuple[str, float, str]]], Tuple[float, str]] # Combines all the test case outputs (name, score, err)

def packer_compile(ex: str, grader_ex: str) -> Optional[str]:
    os.system(f'mkdir {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {EXTRACT_DIR}_{threading.get_native_id()}/{ex}/packer.c {COMPILE_DIR}_{threading.get_native_id()} > /dev/null 2> /dev/null')
    os.system(f'cp {GRADER_DIR}/{grader_ex}/{grader_ex}.c {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {SKELETON_DIR}/{grader_ex}/packer.h {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {SKELETON_DIR}/{grader_ex}/Makefile {COMPILE_DIR}_{threading.get_native_id()}')
    p = subprocess.Popen(['make'], cwd=f'{COMPILE_DIR}_{threading.get_native_id()}', stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    _, stderr = p.communicate()
    rc = p.returncode
    if rc:
        # Return the last non-empty line
        parts = stderr.decode('utf-8').split('\n')
        for part in reversed(parts):
            if part:
                return f'Compilation error: {part}'
        return 'Compilation error'

def packer_test_case_std(ex: str, grader_ex: str, checker_ex: str, name: str) -> Tuple[float, str]:
    os.system(f'mkdir {EXEC_DIR}_{threading.get_native_id()}')
    os.system(f'cp {COMPILE_DIR}_{threading.get_native_id()}/{grader_ex} {EXEC_DIR}_{threading.get_native_id()}')
    os.system(f'cp {TESTCASE_DIR}/{ex}/{name}.in {EXEC_DIR}_{threading.get_native_id()}')
    with open(f'{EXEC_DIR}_{threading.get_native_id()}/{name}.in', 'r') as input_file:
        p = subprocess.Popen([f'./{grader_ex}', 'output.txt'], cwd=f'{EXEC_DIR}_{threading.get_native_id()}', stdin=input_file, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            p.wait(timeout=20)
            rc1 = p.returncode
        except subprocess.TimeoutExpired:
            p.kill()
            return (0, 'Time limit exceeded (took more than 20 seconds, you probably have a deadlock, or a ball that we expected was not returned)')
    p = subprocess.Popen([f'./{CHECKER_DIR}/{checker_ex}_checker', f'{TESTCASE_DIR}/{ex}/{name}.in', f'{EXEC_DIR}_{threading.get_native_id()}/output.txt'], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    rc = p.returncode
    if rc:
        if rc1 == -11:
            # Grader segfaulted, probably the student's fault
            return (0, 'Signal 11 (Segmentation fault)')
        if rc1 == -6:
            # Grader aborted, probably the student's fault
            return (0, 'Signal 6 (Aborted)')
        print(ex)
        print(name)
        print(threading.get_native_id())
        print(rc1)
        print(stderr.decode("utf-8"))
        while True:
            pass
        # Probably our fault
        raise RuntimeError(f'Checker error: {stderr.decode("utf-8")}')
    parts = stdout.decode('utf-8').split('\n')
    # if parts[0] == '0':
    #     print(name)
    #     print(threading.get_native_id())
    #     print(parts[1])
    #     while True: pass
    return (int(parts[0]), parts[1])

def restaurant_compile(ex: str) -> Optional[str]:
    os.system(f'mkdir {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {EXTRACT_DIR}_{threading.get_native_id()}/{ex}/restaurant.c {COMPILE_DIR}_{threading.get_native_id()} > /dev/null 2> /dev/null')
    os.system(f'cp {EXTRACT_DIR}_{threading.get_native_id()}/{ex}/restaurant.h {COMPILE_DIR}_{threading.get_native_id()} > /dev/null 2> /dev/null')
    os.system(f'cp {GRADER_DIR}/ex4/ex4.c {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {GRADER_DIR}/ex4/ex4_adaptive.c {COMPILE_DIR}_{threading.get_native_id()}')
    os.system(f'cp {GRADER_DIR}/ex4/Makefile {COMPILE_DIR}_{threading.get_native_id()}')
    p = subprocess.Popen(['make', 'EXERCISE=' + ex[-1]], cwd=f'{COMPILE_DIR}_{threading.get_native_id()}', stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    _, stderr = p.communicate()
    rc = p.returncode
    if rc:
        # Return the last non-empty line
        parts = stderr.decode('utf-8').split('\n')
        for part in reversed(parts):
            if part:
                return f'Compilation error: {part}'
        return 'Compilation error'

def restaurant_test_case_std(ex: str, name: str) -> Tuple[float, str]:
    os.system(f'mkdir {EXEC_DIR}_{threading.get_native_id()}')
    os.system(f'cp {COMPILE_DIR}_{threading.get_native_id()}/ex4 {EXEC_DIR}_{threading.get_native_id()}')
    os.system(f'cp {TESTCASE_DIR}/{ex}/{name}.in {EXEC_DIR}_{threading.get_native_id()}')
    with open(f'{EXEC_DIR}_{threading.get_native_id()}/{name}.in', 'r') as input_file:
        p = subprocess.Popen(['./ex4', 'output.txt'], cwd=f'{EXEC_DIR}_{threading.get_native_id()}', stdin=input_file, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            p.wait(timeout=20)
            rc1 = p.returncode
        except subprocess.TimeoutExpired:
            p.kill()
            return (0, 'Time limit exceeded (took more than 20 seconds, you probably have a deadlock)')
    p = subprocess.Popen([f'./{CHECKER_DIR}/{ex}_checker', f'{TESTCASE_DIR}/{ex}/{name}.in', f'{EXEC_DIR}_{threading.get_native_id()}/output.txt'], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    rc = p.returncode
    if rc:
        if rc1 == -11:
            # Grader segfaulted, probably the student's fault
            return (0, 'Signal 11 (Segmentation fault)')
        if rc1 == -6:
            # Grader aborted, probably the student's fault
            return (0, 'Signal 6 (Aborted)')
        print(ex)
        print(name)
        print(threading.get_native_id())
        print(rc1)
        print(stderr.decode("utf-8"))
        while True:
            pass
        # Probably our fault
        raise RuntimeError(f'Checker error: {stderr.decode("utf-8")}')
    parts = stdout.decode('utf-8').split('\n')
    # if parts[0] == '0':
    #     print(name)
    #     print(threading.get_native_id())
    #     while True: pass
    return (int(parts[0]), parts[1])

def restaurant_test_case_adaptive(ex: str, name: str, modifier: str) -> Tuple[float, str]:
    os.system(f'mkdir {EXEC_DIR}_{threading.get_native_id()}')
    os.system(f'cp {COMPILE_DIR}_{threading.get_native_id()}/ex4_adaptive_{modifier} {EXEC_DIR}_{threading.get_native_id()}')
    # os.system(f'cp {TESTCASE_DIR}/{ex}/{name}.in {EXEC_DIR}_{threading.get_native_id()}')
    with open(f'{TESTCASE_DIR}/{ex}/{name}.in', 'r') as input_cmd_args:
        args = input_cmd_args.read().split()
        p = subprocess.Popen([f'./ex4_adaptive_{modifier}', 'input.txt', 'output.txt'] + args, cwd=f'{EXEC_DIR}_{threading.get_native_id()}', stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        p.wait(timeout=20)
        rc1 = p.returncode
    except subprocess.TimeoutExpired:
        p.kill()
        # print(name)
        # print(threading.get_native_id())
        # print(args)
        # while True: pass
        return (0, 'Time limit exceeded (took more than 20 seconds, you probably have a deadlock)')
    p = subprocess.Popen([f'./{CHECKER_DIR}/{ex}_checker', f'{EXEC_DIR}_{threading.get_native_id()}/input.txt', f'{EXEC_DIR}_{threading.get_native_id()}/output.txt'], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    rc = p.returncode
    if rc:
        if rc1 == -11:
            # Grader segfaulted, probably the student's fault
            return (0, 'Signal 11 (Segmentation fault)')
        if rc1 == -6:
            # Grader aborted, probably the student's fault
            return (0, 'Signal 6 (Aborted)')
        print(ex)
        print(name)
        print(threading.get_native_id())
        print(rc1)
        print(stderr.decode("utf-8"))
        while True:
            pass
        # Probably our fault
        raise RuntimeError(f'Checker error: {stderr.decode("utf-8")}')
    parts = stdout.decode('utf-8').split('\n')
    # if parts[0] == '0':
    #     print(name)
    #     print(threading.get_native_id())
    #     print(parts[1])
    #     print(args)
    #     while True: pass
    return (int(parts[0]), parts[1])

def ex1_test_case_std(name: str) -> Tuple[float, str]:
    return packer_test_case_std('ex1', 'ex1', 'ex1', name)

def ex2_test_case_std(name: str) -> Tuple[float, str]:
    return packer_test_case_std('ex2', 'ex1', 'ex1', name)

def ex3_test_case_std(name: str) -> Tuple[float, str]:
    return packer_test_case_std('ex3', 'ex3', 'ex3', name)

def ex4_test_case_std(name: str) -> Tuple[float, str]:
    return restaurant_test_case_std('ex4', name)

def ex5_test_case_std(name: str) -> Tuple[float, str]:
    return restaurant_test_case_std('ex5', name)

def ex6_test_case_std(name: str) -> Tuple[float, str]:
    return restaurant_test_case_std('ex6', name)

def ex4_test_case_adaptive_seq(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex4', name, 'seq')

def ex4_test_case_adaptive_par(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex4', name, 'par')

def ex5_test_case_adaptive_seq(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex5', name, 'seq')

def ex5_test_case_adaptive_par(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex5', name, 'par')

def ex6_test_case_adaptive_seq(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex6', name, 'seq')

def ex6_test_case_adaptive_par(name: str) -> Tuple[float, str]:
    return restaurant_test_case_adaptive('ex6', name, 'par')

def concat_scorer(results: List[Tuple[str, float, str]]) -> Tuple[float, str]:
    score: float = 0
    err: List[str] = []
    for (name, s, e) in results:
        score += s
        if e:
            err.append(f'{name}: {e}')
    if len(err):
        return (score, '\n'.join(err))
    else:
        return (score, 'Perfect!')

def ex1_scorer(results: List[Tuple[str, float, str]]) -> Tuple[float, str]:
    # For ex1 (total 1 mark):
    #   0.15 mark for sequential non-tiny tests
    #   0.1 mark for sequential tests
    #   0.45 mark for all non-tiny tests
    #   0.3 mark for all tests
    seq_non_tiny_correct: bool = True
    seq_correct: bool = True
    all_non_tiny_correct: bool = True
    all_correct: bool = True
    err: List[str] = []
    for (name, s, e) in results:
        if e:
            err.append(f'{name}: {e}')
        if s != 1:
            all_correct = False
            if name.find("seq") != -1:
                seq_correct = False
            if name.find("tiny") == -1:
                all_non_tiny_correct = False
            if name.find("seq") != -1 and name.find("tiny") == -1:
                seq_non_tiny_correct = False
    score: float = 0.15 * int(seq_non_tiny_correct) + 0.1 * int(seq_correct) + 0.45 * int(all_non_tiny_correct) + 0.3 * int(all_correct)
    score = round(score, 4) # needed due to float inaccuracies
    if len(err):
        return (score, '\n'.join(err))
    else:
        return (score, 'Perfect!')

def ex2_scorer(results: List[Tuple[str, float, str]]) -> Tuple[float, str]:
    # For ex2 (total 1 mark):
    #   0.25 mark for sequential tests
    #     -0.05 mark for each incorrect test case
    #   0.75 mark for all tests
    #     -0.15 mark for each incorrect test case
    seq_num_incorrect: int = 0
    all_num_incorrect: int = 0
    err: List[str] = []
    for (name, s, e) in results:
        if e:
            err.append(f'{name}: {e}')
        if s != 1:
            all_num_incorrect += 1
            if name.find("seq") != -1:
                seq_num_incorrect += 1
    score: float = max(0, 0.25 - 0.05 * seq_num_incorrect) + max(0, 0.75 - 0.15 * all_num_incorrect)
    score = round(score, 4) # needed due to float inaccuracies
    if len(err):
        return (score, '\n'.join(err))
    else:
        return (score, 'Perfect!')

def ex3_scorer(results: List[Tuple[str, float, str]]) -> Tuple[float, str]:
    # For ex3 (total 2 marks):
    #   0.5 mark for sequential tests
    #     -0.1 mark for each incorrect test case
    #   1.5 mark for all tests
    #     -0.3 mark for each incorrect test case
    seq_num_incorrect: int = 0
    all_num_incorrect: int = 0
    err: List[str] = []
    for (name, s, e) in results:
        if e:
            err.append(f'{name}: {e}')
        if s != 1:
            all_num_incorrect += 1
            if name.find("seq") != -1:
                seq_num_incorrect += 1
    score: float = max(0, 0.5 - 0.1 * seq_num_incorrect) + max(0, 1.5 - 0.3 * all_num_incorrect)
    score = round(score, 4) # needed due to float inaccuracies
    if len(err):
        return (score, '\n'.join(err))
    else:
        return (score, 'Perfect!')

def restaurant_scorer(results: List[Tuple[str, float, str]]) -> Tuple[float, str]:
    # For ex4 and ex5 and ex6 (total 2 marks):
    #   0.5 mark for sequential tests
    #     -0.1 mark for each incorrect test case
    #   1.5 mark for all tests
    #     -0.3 mark for each incorrect test case
    seq_num_incorrect: int = 0
    all_num_incorrect: int = 0
    err: List[str] = []
    for (name, s, e) in results:
        if e:
            err.append(f'{name}: {e}')
        if s != 1:
            all_num_incorrect += 1
            if name.find("seq") != -1:
                seq_num_incorrect += 1
    score: float = max(0, 0.5 - 0.1 * seq_num_incorrect) + max(0, 1.5 - 0.3 * all_num_incorrect)
    score = round(score, 4) # needed due to float inaccuracies
    if len(err):
        return (score, '\n'.join(err))
    else:
        return (score, 'Perfect!')

ex1_test_cases = [
    TestCase(name='seq_test_1', execute=lambda: ex1_test_case_std('seq_test_1')),
    TestCase(name='seq_test_2', execute=lambda: ex1_test_case_std('seq_test_2')),
    TestCase(name='seq_test_3', execute=lambda: ex1_test_case_std('seq_test_3')),
    TestCase(name='par_test_1', execute=lambda: ex1_test_case_std('par_test_1')),
    TestCase(name='par_test_2', execute=lambda: ex1_test_case_std('par_test_2')),
    TestCase(name='par_test_3', execute=lambda: ex1_test_case_std('par_test_3')),
    TestCase(name='par_test_4', execute=lambda: ex1_test_case_std('par_test_4')),
    TestCase(name='seq_tiny_test_1', execute=lambda: ex1_test_case_std('seq_tiny_test_1')),
    TestCase(name='seq_tiny_test_2', execute=lambda: ex1_test_case_std('seq_tiny_test_2')),
    TestCase(name='seq_tiny_test_3', execute=lambda: ex1_test_case_std('seq_tiny_test_3')),
    TestCase(name='seq_tiny_test_4', execute=lambda: ex1_test_case_std('seq_tiny_test_4')),
    TestCase(name='seq_tiny_test_5', execute=lambda: ex1_test_case_std('seq_tiny_test_5')),
    TestCase(name='par_tiny_test_1', execute=lambda: ex1_test_case_std('par_tiny_test_1')),
    TestCase(name='par_tiny_test_2', execute=lambda: ex1_test_case_std('par_tiny_test_2')),
    TestCase(name='par_tiny_test_3', execute=lambda: ex1_test_case_std('par_tiny_test_3')),
    TestCase(name='par_tiny_test_4', execute=lambda: ex1_test_case_std('par_tiny_test_4'))
]

ex2_test_cases = [
    TestCase(name='par_test', execute=lambda: ex2_test_case_std('par_test')),
    TestCase(name='par_order_test', execute=lambda: ex2_test_case_std('par_order_test')),
    TestCase(name='seq_test', execute=lambda: ex2_test_case_std('seq_test')),
    TestCase(name='seq_random_small_1', execute=lambda: ex2_test_case_std('seq_random_small_1')),
    TestCase(name='seq_random_small_2', execute=lambda: ex2_test_case_std('seq_random_small_2')),
    TestCase(name='seq_random_small_3', execute=lambda: ex2_test_case_std('seq_random_small_3')),
    TestCase(name='seq_random_small_4', execute=lambda: ex2_test_case_std('seq_random_small_4')),
    TestCase(name='seq_random_small_5', execute=lambda: ex2_test_case_std('seq_random_small_5')),
    TestCase(name='seq_random_large_1', execute=lambda: ex2_test_case_std('seq_random_large_1')),
    TestCase(name='seq_random_large_2', execute=lambda: ex2_test_case_std('seq_random_large_2')),
    TestCase(name='par_random_small_1', execute=lambda: ex2_test_case_std('par_random_small_1')),
    TestCase(name='par_random_small_2', execute=lambda: ex2_test_case_std('par_random_small_2')),
    TestCase(name='par_random_small_3', execute=lambda: ex2_test_case_std('par_random_small_3')),
    TestCase(name='par_random_small_4', execute=lambda: ex2_test_case_std('par_random_small_4')),
    TestCase(name='par_random_small_5', execute=lambda: ex2_test_case_std('par_random_small_5')),
    TestCase(name='par_random_large_1', execute=lambda: ex2_test_case_std('par_random_large_1')),
    TestCase(name='par_random_large_2', execute=lambda: ex2_test_case_std('par_random_large_2')),
    TestCase(name='par_random_large_3', execute=lambda: ex2_test_case_std('par_random_large_3'))
]

ex3_test_cases = [
    TestCase(name='test', execute=lambda: ex3_test_case_std('test')),
    TestCase(name='seq_random_small_1', execute=lambda: ex3_test_case_std('seq_random_small_1')),
    TestCase(name='seq_random_small_2', execute=lambda: ex3_test_case_std('seq_random_small_2')),
    TestCase(name='seq_random_small_3', execute=lambda: ex3_test_case_std('seq_random_small_3')),
    TestCase(name='seq_random_small_4', execute=lambda: ex3_test_case_std('seq_random_small_4')),
    TestCase(name='seq_random_small_5', execute=lambda: ex3_test_case_std('seq_random_small_5')),
    TestCase(name='seq_random_small_6', execute=lambda: ex3_test_case_std('seq_random_small_6')),
    TestCase(name='seq_random_small_7', execute=lambda: ex3_test_case_std('seq_random_small_7')),
    TestCase(name='seq_random_large_1', execute=lambda: ex3_test_case_std('seq_random_large_1')),
    TestCase(name='seq_random_large_2', execute=lambda: ex3_test_case_std('seq_random_large_2')),
    TestCase(name='seq_random_large_3', execute=lambda: ex3_test_case_std('seq_random_large_3')),
    TestCase(name='seq_random_large_4', execute=lambda: ex3_test_case_std('seq_random_large_4')),
    TestCase(name='par_random_small_1', execute=lambda: ex3_test_case_std('par_random_small_1')),
    TestCase(name='par_random_small_2', execute=lambda: ex3_test_case_std('par_random_small_2')),
    TestCase(name='par_random_small_3', execute=lambda: ex3_test_case_std('par_random_small_3')),
    TestCase(name='par_random_small_4', execute=lambda: ex3_test_case_std('par_random_small_4')),
    TestCase(name='par_random_small_5', execute=lambda: ex3_test_case_std('par_random_small_5')),
    TestCase(name='par_random_small_6', execute=lambda: ex3_test_case_std('par_random_small_6')),
    TestCase(name='par_random_small_7', execute=lambda: ex3_test_case_std('par_random_small_7')),
    TestCase(name='par_random_small_8', execute=lambda: ex3_test_case_std('par_random_small_8')),
    TestCase(name='par_random_small_9', execute=lambda: ex3_test_case_std('par_random_small_9')),
    TestCase(name='par_random_small_10', execute=lambda: ex3_test_case_std('par_random_small_10')),
    TestCase(name='par_random_small_11', execute=lambda: ex3_test_case_std('par_random_small_11')),
    TestCase(name='par_random_large_1', execute=lambda: ex3_test_case_std('par_random_large_1')),
    TestCase(name='par_random_large_2', execute=lambda: ex3_test_case_std('par_random_large_2')),
    TestCase(name='par_random_large_3', execute=lambda: ex3_test_case_std('par_random_large_3')),
    TestCase(name='par_random_large_4', execute=lambda: ex3_test_case_std('par_random_large_4')),
    TestCase(name='par_random_large_5', execute=lambda: ex3_test_case_std('par_random_large_5'))
]

ex4_test_cases = [
    TestCase(name='seq_test', execute=lambda: ex4_test_case_std('seq_test')),
    TestCase(name='seq_random_1', execute=lambda: ex4_test_case_adaptive_seq('seq_random_1')),
    TestCase(name='seq_random_2', execute=lambda: ex4_test_case_adaptive_seq('seq_random_2')),
    TestCase(name='seq_random_3', execute=lambda: ex4_test_case_adaptive_seq('seq_random_3')),
    TestCase(name='seq_random_4', execute=lambda: ex4_test_case_adaptive_seq('seq_random_4')),
    TestCase(name='seq_random_5', execute=lambda: ex4_test_case_adaptive_seq('seq_random_5')),
    TestCase(name='seq_random_6', execute=lambda: ex4_test_case_adaptive_seq('seq_random_6')),
    TestCase(name='par_random_1', execute=lambda: ex4_test_case_adaptive_par('par_random_1')),
    TestCase(name='par_random_2', execute=lambda: ex4_test_case_adaptive_par('par_random_2')),
    TestCase(name='par_random_3', execute=lambda: ex4_test_case_adaptive_par('par_random_3')),
    TestCase(name='par_random_4', execute=lambda: ex4_test_case_adaptive_par('par_random_4')),
    TestCase(name='par_random_5', execute=lambda: ex4_test_case_adaptive_par('par_random_5')),
    TestCase(name='par_random_6', execute=lambda: ex4_test_case_adaptive_par('par_random_6')),
    TestCase(name='par_random_7', execute=lambda: ex4_test_case_adaptive_par('par_random_7'))
]

ex5_test_cases = [
    TestCase(name='seq_test', execute=lambda: ex5_test_case_std('seq_test')),
    TestCase(name='seq_random_1', execute=lambda: ex5_test_case_adaptive_seq('seq_random_1')),
    TestCase(name='seq_random_2', execute=lambda: ex5_test_case_adaptive_seq('seq_random_2')),
    TestCase(name='seq_random_3', execute=lambda: ex5_test_case_adaptive_seq('seq_random_3')),
    TestCase(name='seq_random_4', execute=lambda: ex5_test_case_adaptive_seq('seq_random_4')),
    TestCase(name='seq_random_5', execute=lambda: ex5_test_case_adaptive_seq('seq_random_5')),
    TestCase(name='seq_random_6', execute=lambda: ex5_test_case_adaptive_seq('seq_random_6')),
    TestCase(name='par_random_1', execute=lambda: ex5_test_case_adaptive_par('par_random_1')),
    TestCase(name='par_random_2', execute=lambda: ex5_test_case_adaptive_par('par_random_2')),
    TestCase(name='par_random_3', execute=lambda: ex5_test_case_adaptive_par('par_random_3')),
    TestCase(name='par_random_4', execute=lambda: ex5_test_case_adaptive_par('par_random_4')),
    TestCase(name='par_random_5', execute=lambda: ex5_test_case_adaptive_par('par_random_5')),
    TestCase(name='par_random_6', execute=lambda: ex5_test_case_adaptive_par('par_random_6')),
    TestCase(name='par_random_7', execute=lambda: ex5_test_case_adaptive_par('par_random_7'))
]

ex6_test_cases = [
    TestCase(name='seq_test', execute=lambda: ex6_test_case_std('seq_test')),
    TestCase(name='seq_random_1', execute=lambda: ex6_test_case_adaptive_seq('seq_random_1')),
    TestCase(name='seq_random_2', execute=lambda: ex6_test_case_adaptive_seq('seq_random_2')),
    TestCase(name='seq_random_3', execute=lambda: ex6_test_case_adaptive_seq('seq_random_3')),
    TestCase(name='seq_random_4', execute=lambda: ex6_test_case_adaptive_seq('seq_random_4')),
    TestCase(name='seq_random_5', execute=lambda: ex6_test_case_adaptive_seq('seq_random_5')),
    TestCase(name='seq_random_6', execute=lambda: ex6_test_case_adaptive_seq('seq_random_6')),
    TestCase(name='par_random_1', execute=lambda: ex6_test_case_adaptive_par('par_random_1')),
    TestCase(name='par_random_2', execute=lambda: ex6_test_case_adaptive_par('par_random_2')),
    TestCase(name='par_random_3', execute=lambda: ex6_test_case_adaptive_par('par_random_3')),
    TestCase(name='par_random_4', execute=lambda: ex6_test_case_adaptive_par('par_random_4')),
    TestCase(name='par_random_5', execute=lambda: ex6_test_case_adaptive_par('par_random_5')),
    TestCase(name='par_random_6', execute=lambda: ex6_test_case_adaptive_par('par_random_6')),
    TestCase(name='par_random_7', execute=lambda: ex6_test_case_adaptive_par('par_random_7'))
]

test_spec = [
    Exercise(name='Ex1', compile=lambda: packer_compile('ex1', 'ex1'), test_cases=ex1_test_cases, score=ex1_scorer),
    Exercise(name='Ex2', compile=lambda: packer_compile('ex2', 'ex1'), test_cases=ex2_test_cases, score=ex2_scorer),
    Exercise(name='Ex3', compile=lambda: packer_compile('ex3', 'ex3'), test_cases=ex3_test_cases, score=ex3_scorer),
    Exercise(name='Ex4', compile=lambda: restaurant_compile('ex4'), test_cases=ex4_test_cases, score=restaurant_scorer),
    Exercise(name='Ex5', compile=lambda: restaurant_compile('ex5'), test_cases=ex5_test_cases, score=restaurant_scorer),
    Exercise(name='Ex6', compile=lambda: restaurant_compile('ex6'), test_cases=ex6_test_cases, score=restaurant_scorer)
]

NUSNETID_REGEX = re.compile('^e[0-9]{7}$', re.IGNORECASE)

# Extract submission, returning an error if it failed
def extract_submission(submission_file: str) -> Optional[str]:
    os.system(f'unzip -qq {submission_file} -d {EXTRACT_DIR}_{threading.get_native_id()}')
    if not os.path.exists(f'{EXTRACT_DIR}_{threading.get_native_id()}'):
        return f'Failed to unzip submission file'
    
    # Some students will add another directory within the zip file, so we need to move the folders out
    nested_dir = None
    for dir in os.listdir(f'{EXTRACT_DIR}_{threading.get_native_id()}'):
        if NUSNETID_REGEX.match(dir) or dir == "submission":
            nested_dir = dir
            break
    if nested_dir:
        os.system(f'mv {EXTRACT_DIR}_{threading.get_native_id()}/{nested_dir}/* {EXTRACT_DIR}_{threading.get_native_id()}')

def cleanup_if_needed(dir: str) -> None:
    if os.path.exists(dir):
        os.system(f'rm -rf {dir} > /dev/null 2> /dev/null')
    while os.path.exists(dir):
        print(f'Cannot remove \'{dir}\', retrying...')
        time.sleep(1) # sometimes removing the directory fails spuriously...
        os.system(f'rm -rf {dir} > /dev/null 2> /dev/null')

def execute_and_cleanup(execute: Callable[[], Tuple[float, str]], name: str) -> Tuple[str, float, str]:
    try:
        (score, err) = execute()
        return (name, score, err)
    finally:
        cleanup_if_needed(f'{EXEC_DIR}_{threading.get_native_id()}')

# Returns the list of things to write into the CSV file
def grade_submission(submission: str) -> List[Tuple[float, str]]:
    try:
        err = extract_submission(submission)
        if err:
            raise RuntimeError(err)
        results = []
        for exercise_spec in test_spec:
            try:
                err = exercise_spec.compile()
                if err:
                    exercise_result = (0, err)
                else:
                    test_results = [execute_and_cleanup(test_case.execute, test_case.name) for test_case in exercise_spec.test_cases]
                    exercise_result = exercise_spec.score(test_results)
                results.append(exercise_result)
            finally:
                cleanup_if_needed(f'{COMPILE_DIR}_{threading.get_native_id()}')
        return results
    finally:
        cleanup_if_needed(f'{EXTRACT_DIR}_{threading.get_native_id()}')

# Grade all submissions and write them to a csv file
def grade_all(filename: str, submission_folder: str) -> None:
    executor = concurrent.futures.ProcessPoolExecutor(4)

    # Open the CSV file
    with open(filename, 'w') as file:
        csvwriter = csv.writer(file)
        csvwriter.writerow(['UserID'] + list(chain.from_iterable((f'{exercise_spec.name}_score', f'{exercise_spec.name}_remark') for exercise_spec in test_spec)))
        submissions = [submission for submission in os.listdir(submission_folder)]
        submissions.sort()
        futures_submissions = [(executor.submit(grade_submission, submission_folder + '/' + submission), submission) for submission in submissions]
        for i, (future, submission) in enumerate(futures_submissions):
            print(f'Graded {i} of {len(submissions)}...')
            results = future.result()
            csvwriter.writerow([submission.split('.', 1)[0]] + list(chain.from_iterable((score, err) for (score, err) in results)))
            file.flush()
        # for i, submission in enumerate(submissions):
        #     print(f'Graded {i} of {len(submissions)}...')
        #     results = grade_submission(submission_folder + '/' + submission)
        #     csvwriter.writerow([submission.split('.', 1)[0]] + list(chain.from_iterable((score, err) for (score, err) in results)))
        #     file.flush()
    print('Complete!')

if __name__ == '__main__':
    grade_all('output.csv', SUBMISSION_DIR)
