#include <semaphore.h>
#include <stddef.h>

#include "packer.h"

typedef struct {
    sem_t mtx;
    sem_t first_waiter;
    sem_t other_waiter;
    sem_t turnstile;
    int first_id;
    int *other_ids;
    int num_waiting;
} data_barrier;

data_barrier barr[3];

int n;

void packer_init(int balls_per_pack) {
    n = balls_per_pack - 1;
    for (int i = 0; i < 3; ++i){
        sem_init(&barr[i].mtx, 0, 1);
        sem_init(&barr[i].first_waiter, 0, 0);
        sem_init(&barr[i].other_waiter, 0, 0);
        sem_init(&barr[i].turnstile, 0, 1);
        barr[i].other_ids = NULL;
    }
}

void packer_destroy(void) {
    for (int i = 0; i < 3; ++i){
        sem_destroy(&barr[i].mtx);
        sem_destroy(&barr[i].first_waiter);
        sem_destroy(&barr[i].other_waiter);
        sem_destroy(&barr[i].turnstile);
    }
}

void pack_ball(int colour, int id, int *other_ids) {
    data_barrier *b = &barr[colour - 1];
    sem_wait(&b->mtx);
    if (b->other_ids) { // other threads are already waiting
        int *orig_other_ids = b->other_ids;
        orig_other_ids[b->num_waiting++] = id;
        int num_waiting = b->num_waiting;
        if (num_waiting == n) { // this is the last ball of the group
            b->other_ids = NULL;
            sem_post(&b->mtx);
            for (int i = 1; i < n; ++i) {
                sem_post(&b->other_waiter);
            }
        }
        else {
            sem_post(&b->mtx);
            sem_wait(&b->other_waiter);
        }
        {
            // This pair of loops ensure that if there's another ball with the same id as us,
            // we still keep their id even though we discard our own id.
            int i;
            for (i = 0; orig_other_ids[i] != id; ++i){
                *other_ids++ = orig_other_ids[i];
            }
            for (++i; i < n; ++i){
                *other_ids++ = orig_other_ids[i];
            }
        }
        *other_ids = b->first_id;
        sem_post(&b->first_waiter);
    }
    else {
        b->other_ids = other_ids;
        sem_wait(&b->turnstile);
        b->first_id = id;
        b->num_waiting = 0;
        sem_post(&b->mtx);
        for (int i = 0; i < n; ++i){
            sem_wait(&b->first_waiter);
        }
        sem_post(&b->turnstile);
    }
}
