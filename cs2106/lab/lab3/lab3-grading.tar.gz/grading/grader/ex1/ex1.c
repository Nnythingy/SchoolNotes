// This is the grader for ex1.
// The main differences are that:
// - It prints some slightly more machine-readable output without fluff
// - It waits for the correct number of balls to be received

#include <stdio.h>
#include <stddef.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <assert.h>
#include <errno.h>
#include <string.h>

#include "packer.h"

// The standard input stream should contain a space-separated list of characters
// where each character is in {1, 2, 3, .}.  If it is a positive integer, that is the
// colour of a ball, and the id follows.  If it is '.', that is a synchronization barrier for the
// grader code.
// Output is written to a file, instead of stdout, so that debugging output from student's code don't appear

static void assert_malloc_succeeded(void *ptr) {
    if (!ptr) {
        fprintf(stderr, "Out of memory!\n");
        abort();
    }
}

typedef struct cmdlist {
    int id;
    int colour;
    struct cmdlist *next;
} cmdlist;

static unsigned cmdlist_size(cmdlist *cmds) {
    unsigned ct = 0;
    while (cmds) {
        cmds = cmds->next;
        ++ct;
    }
    return ct;
}

typedef struct {
    atomic_uint num_ready;
    atomic_bool go;
    atomic_uint num_started;
} busywaiter;

static void busywaiter_init(busywaiter *waiter) {
    atomic_init(&(waiter->num_ready), 0);
    atomic_init(&(waiter->go), false);
    atomic_init(&(waiter->num_started), 0);
}

static void busywaiter_destroy(busywaiter *waiter) {
    (void) waiter;
}

static void busywaiter_ball_wait(busywaiter *waiter) {
    atomic_fetch_add_explicit(&(waiter->num_ready), 1, memory_order_acq_rel);
    while (!atomic_load_explicit(&(waiter->go), memory_order_acquire));
    atomic_fetch_add_explicit(&(waiter->num_started), 1, memory_order_acq_rel);
}

static void busywaiter_main_wait(busywaiter *waiter, unsigned num_threads) {
    while (atomic_load_explicit(&(waiter->num_ready), memory_order_acquire) != num_threads);
    atomic_store_explicit(&(waiter->go), true, memory_order_release);
    while (atomic_load_explicit(&(waiter->num_started), memory_order_acquire) != num_threads);
}

typedef struct ballinfo {
    // Set by the main thread
    int my_id;
    int my_colour;
    pthread_t thread;
    busywaiter *waiter;
    struct ballinfo **jlist;
    pthread_mutex_t *jmutex;
    sem_t *done_sem;

    // Set by the ball thread
    int other_id;
    struct ballinfo *next;
} ballinfo;

static void* run_ball(void *context) {
    ballinfo *info = context;
    busywaiter_ball_wait(info->waiter);
    info->other_id = pack_ball(info->my_colour, info->my_id);
    pthread_mutex_lock(info->jmutex);
    info->next = *(info->jlist);
    *(info->jlist) = info;
    pthread_mutex_unlock(info->jmutex);
    sem_post(info->done_sem);
    return NULL;
}

typedef struct {
    int numballs[3];
} ballstate;

void ballstate_init(ballstate *b) {
    b->numballs[0] = b->numballs[1] = b->numballs[2] = 0;
}

// Returns the number of balls that should be released.
int ballstate_push(ballstate *b, int colour) {
    int* tmp = &b->numballs[colour - 1];
    ++(*tmp);
    if (*tmp == 2) {
        *tmp = 0;
        return 2;
    }
    return 0;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./ex1_checker <output_file>\n");
        return 1;
    }
    FILE* output_file = fopen(argv[1], "w");
    if (!output_file) {
        fprintf(stderr, "Cannot open output file for writing\n");
        return 1;
    }
    int balls_per_pack;
    scanf("%d", &balls_per_pack);
    if (balls_per_pack != 2) {
        fprintf(stderr, "Expected two balls per box, but got \"%d\"!\n", balls_per_pack);
        return 1;
    }
    packer_init();

    cmdlist *cmds = NULL;
    ballinfo *jlist = NULL;
    pthread_mutex_t jmutex;
    pthread_mutex_init(&jmutex, NULL);
    ballstate bst;
    ballstate_init(&bst);
    int expected = 0;
    sem_t done_sem;
    if (sem_init(&done_sem, 0, 0)) {
        fprintf(stderr, "sem_init() failed: %s\n", strerror(errno));
        abort();
    }

    while (1) {
        int res;
        while (1) {
            char ch;
            res = scanf(" %c", &ch);
            if (res < 1 || ch == '.') break;
            if (ch < '1' || ch > '3') {
                fprintf(stderr, "Invalid command \"%c\"!\n", ch);
                abort();
            }
            int id;
            scanf("%d", &id);
            cmdlist *new_cmd = malloc(sizeof(cmdlist));
            assert_malloc_succeeded(new_cmd);
            new_cmd->id = id;
            new_cmd->colour = ch - '0';
            new_cmd->next = cmds;
            cmds = new_cmd;
        }
        unsigned num_threads = cmdlist_size(cmds);
        if (num_threads) {
            // these stuff to help ensure that threads start at the same time,
            // in the hope of triggering some race conditions.
            busywaiter waiter;
            busywaiter_init(&waiter);

            for (cmdlist *it = cmds; it; it = it->next) {
                expected += ballstate_push(&bst, it->colour);
                ballinfo *info = malloc(sizeof(ballinfo));
                assert_malloc_succeeded(info);
                info->my_id = it->id;
                info->my_colour = it->colour;
                info->waiter = &waiter;
                info->jlist = &jlist;
                info->jmutex = &jmutex;
                info->done_sem = &done_sem;
                int err;
                if ((err = pthread_create(&(info->thread), NULL, &run_ball, info))) {
                    fprintf(stderr, "pthread_create() failed: %d\n", err);
                    abort();
                }
            }
            busywaiter_main_wait(&waiter, num_threads);
            busywaiter_destroy(&waiter);
        }
        while (cmds) {
            cmdlist *tmp = cmds->next;
            free(cmds);
            cmds = tmp;
        }
        struct timespec three_seconds_later;
        clock_gettime(CLOCK_REALTIME, &three_seconds_later);
        three_seconds_later.tv_sec += 3;
        while (expected > 0) {
            int sem_ret = sem_timedwait(&done_sem, &three_seconds_later);
            if (sem_ret == -1 && errno == ETIMEDOUT) {
                fprintf(output_file, "A\n"); // timeout error
            }
            if (sem_ret) {
                fprintf(stderr, "sem_timedwait() failed: %d\n", sem_ret);
                abort();
            }
            pthread_mutex_lock(&jmutex);
            assert(jlist);
            --expected;
            fprintf(output_file, "%d %d %d\n", jlist->my_colour, jlist->my_id, jlist->other_id);
            pthread_join(jlist->thread, NULL);
            ballinfo *tmp = jlist->next;
            free(jlist);
            jlist = tmp;
            pthread_mutex_unlock(&jmutex);
        }
        usleep(10000); // sleep for 10ms (during grading, we will wait for at least as many balls as we expect)
        pthread_mutex_lock(&jmutex);
        while (jlist) {
            sem_wait(&done_sem);
            --expected;
            fprintf(output_file, "%d %d %d\n", jlist->my_colour, jlist->my_id, jlist->other_id);
            pthread_join(jlist->thread, NULL);
            ballinfo *tmp = jlist->next;
            free(jlist);
            jlist = tmp;
        }
        pthread_mutex_unlock(&jmutex);
        if (res != EOF) {
            fprintf(output_file, ".\n");
        }
        else {
            break;
        }
    }
    sem_destroy(&done_sem);
    pthread_mutex_destroy(&jmutex);

    packer_destroy();

    fclose(output_file);
}
