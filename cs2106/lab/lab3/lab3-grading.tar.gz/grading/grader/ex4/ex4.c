// This is the grader for ex4-6.
// The main differences are that:
// - It prints some slightly more machine-readable output without fluff
// - It waits until no other ball still in the queue can be seated (this is an easy check).

#include <stdio.h>
#include <stddef.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>
#include <threads.h>
#include <time.h>
#include <unistd.h>

#include "restaurant.h"

// Input:
// Space-separated positive integers: n_1, n_2, n_3, n_4, n_5
// For each remaining line of input file, we have any of:
// . - represents the synchronization separator
// Enter <id> <num_people> - Group with this id and number of people requests for a table
// Leave <id> - Group with this id leaves
//
// It may be assumed that all ids are unique.
// Output is written to a file, instead of stdout, so that debugging output from student's code don't appear

static void assert_malloc_succeeded(void *ptr) {
    if (!ptr) {
        fprintf(stderr, "Out of memory!\n");
        abort();
    }
}

typedef enum {
    CMD_ENTER,
    CMD_LEAVE
} cmd_type;

struct groupinfo;

typedef struct cmdlist {
    cmd_type type;
    int group_id;
    union {
        struct {
            int group_size;
            bool enqueued;
        } enter_data; // used by type == CMD_ENTER
        struct {
            struct groupinfo *info;
        } leave_data; // used by type == CMD_LEAVE
    };
    struct cmdlist *next;
} cmdlist;

static unsigned cmdlist_size(cmdlist *cmds) {
    unsigned ct = 0;
    while (cmds) {
        cmds = cmds->next;
        ++ct;
    }
    return ct;
}

typedef struct {
    atomic_uint num_ready;
    atomic_bool go;
    atomic_uint num_started;
} busywaiter;

static void busywaiter_init(busywaiter *waiter) {
    atomic_init(&(waiter->num_ready), 0);
    atomic_init(&(waiter->go), false);
    atomic_init(&(waiter->num_started), 0);
}

static void busywaiter_destroy(busywaiter *waiter) {
    (void) waiter;
}

static void busywaiter_group_wait(busywaiter *waiter) {
    atomic_fetch_add_explicit(&(waiter->num_ready), 1, memory_order_acq_rel);
    while (!atomic_load_explicit(&(waiter->go), memory_order_acquire));
    atomic_fetch_add_explicit(&(waiter->num_started), 1, memory_order_acq_rel);
}

static void busywaiter_main_wait(busywaiter *waiter, unsigned num_threads) {
    while (atomic_load_explicit(&(waiter->num_ready), memory_order_acquire) != num_threads);
    atomic_store_explicit(&(waiter->go), true, memory_order_release);
    while (atomic_load_explicit(&(waiter->num_started), memory_order_acquire) != num_threads);
}

typedef struct groupinfo {
    // Set by the main thread
    int group_id;
    int group_size;
    pthread_t thread;
    // for pre-enter spin barrier
    busywaiter *waiter;
    // for on_enqueue() reporting
    bool *enqueue_reporter;
    atomic_uint *enqueue_counter;
    // to tell the main thread that this group is currently eating
    struct groupinfo **eating_list;
    pthread_mutex_t *eating_mutex;
    sem_t *done_sem;

    // Set by the group thread
    int table_id;
    sem_t leave_sem; // to signal to us that it's time to leave
    struct groupinfo *next; // for putting in the eating_list
} groupinfo;

groupinfo *groupinfo_find_and_extract(groupinfo **list, int group_id) {
    while (*list) {
        if ((*list)->group_id == group_id) {
            groupinfo *ret = *list;
            *list = (*list)->next;
            return ret;
        }
        list = &(*list)->next;
    }
    return NULL;
}

thread_local groupinfo *this_thread_info;

static void* run_group(void *context) {
    groupinfo *info = context;
    this_thread_info = info;
    busywaiter_group_wait(info->waiter);
    group_state state;
    info->table_id = request_for_table(&state, info->group_size);
    sem_init(&info->leave_sem, 0, 0);
    pthread_mutex_lock(info->eating_mutex);
    info->next = *(info->eating_list);
    *(info->eating_list) = info;
    pthread_mutex_unlock(info->eating_mutex);
    sem_post(info->done_sem);
    sem_wait(&info->leave_sem);
    sem_destroy(&info->leave_sem);
    busywaiter_group_wait(info->waiter);
    leave_table(&state);
    return NULL;
}

void on_enqueue(void) {
    groupinfo *info = this_thread_info;
    *info->enqueue_reporter = true;
    atomic_fetch_add_explicit(info->enqueue_counter, 1, memory_order_release);
}

typedef struct {
    int numqueuedgroups[5];
    int numvacanttables[5];
    int *numemptyseats;
    int *tablesize;
    int tablecount;
    bool is_broken;
} restaurantstate;

void restaurantstate_init(restaurantstate *r, const int *num_tables) {
    for (int i = 0; i < 5; ++i) {
        r->numqueuedgroups[i] = 0;
    }
    int sum = 0;
    for (int i = 0; i < 5; ++i) {
        r->numvacanttables[i] = num_tables[i];
        sum += num_tables[i];
    }
    r->numemptyseats = malloc(sum * sizeof(int));
    r->tablesize = malloc(sum * sizeof(int));
    int k = 0;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < num_tables[i]; ++j) {
            r->numemptyseats[k] = r->tablesize[k] = i + 1;
            ++k;
        }
    }
    r->tablecount = sum;
    r->is_broken = false;
}

void restaurantstate_destroy(restaurantstate *r) {
    free(r->tablesize);
    free(r->numemptyseats);
}

void restaurantstate_enqueue(restaurantstate *r, int groupsize) {
    ++r->numqueuedgroups[groupsize - 1];
}

#if EXERCISE == 4
void restaurantstate_seated(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] != groupsize || r->numemptyseats[table_id] != groupsize) {
        r->is_broken = true;
        return;
    }
    --r->numqueuedgroups[groupsize - 1];
    --r->numvacanttables[r->tablesize[table_id] - 1];
    r->numemptyseats[table_id] -= groupsize;
}
void restaurantstate_leave(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] != groupsize) {
        r->is_broken = true;
        return;
    }
    ++r->numvacanttables[r->tablesize[table_id] - 1];
    r->numemptyseats[table_id] += groupsize;
}
bool restaurantstate_iscomplete(restaurantstate *r) {
    if (r->is_broken) return true;
    for (int i = 0; i < 5; ++i) {
        if (r->numqueuedgroups[i] > 0 && r->numvacanttables[i] > 0) {
            return false;
        }
    }
    return true;
}
#elif EXERCISE == 5
void restaurantstate_seated(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] < groupsize || r->numemptyseats[table_id] < groupsize) {
        r->is_broken = true;
        return;
    }
    --r->numqueuedgroups[groupsize - 1];
    --r->numvacanttables[r->tablesize[table_id] - 1];
    r->numemptyseats[table_id] -= groupsize;
}
void restaurantstate_leave(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] < groupsize) {
        r->is_broken = true;
        return;
    }
    ++r->numvacanttables[r->tablesize[table_id] - 1];
    r->numemptyseats[table_id] += groupsize;
}
bool restaurantstate_iscomplete(restaurantstate *r) {
    if (r->is_broken) return true;
    int collect = 0;
    for (int i = 4; i >=0; --i) {
        collect += r->numvacanttables[i];
        if (r->numqueuedgroups[i] > 0 && collect > 0) {
            return false;
        }
    }
    return true;
}
#elif EXERCISE == 6
void restaurantstate_seated(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] < groupsize || r->numemptyseats[table_id] < groupsize) {
        r->is_broken = true;
        return;
    }
    --r->numqueuedgroups[groupsize - 1];
    --r->numvacanttables[r->numemptyseats[table_id] - 1];
    r->numemptyseats[table_id] -= groupsize;
    if (r->numemptyseats[table_id] > 0) {
        ++r->numvacanttables[r->numemptyseats[table_id] - 1];
    }
}
void restaurantstate_leave(restaurantstate *r, int groupsize, int table_id) {
    if (r->is_broken) return;
    if (table_id < 0 || table_id >= r->tablecount || r->tablesize[table_id] < groupsize || r->numemptyseats[table_id] + groupsize > r->tablesize[table_id]) {
        r->is_broken = true;
        return;
    }
    if (r->numemptyseats[table_id] > 0) {
        --r->numvacanttables[r->numemptyseats[table_id] - 1];
    }
    r->numemptyseats[table_id] += groupsize;
    ++r->numvacanttables[r->numemptyseats[table_id] - 1];
}
bool restaurantstate_iscomplete(restaurantstate *r) {
    if (r->is_broken) return true;
    int collect = 0;
    for (int i = 4; i >=0; --i) {
        collect += r->numvacanttables[i];
        if (r->numqueuedgroups[i] > 0 && collect > 0) {
            return false;
        }
    }
    return true;
}
#endif

int main(int argc, char** argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./ex4 <output_file>\n");
        return 1;
    }
    FILE* output_file = fopen(argv[1], "w");
    if (!output_file) {
        fprintf(stderr, "Cannot open output file for writing\n");
        return 1;
    }
    int num_tables[5];
    for(int i = 0; i < 5; ++i) {
        scanf("%d", &num_tables[i]);
    }
    restaurant_init(num_tables);

    cmdlist *cmds = NULL;
    groupinfo *real_eating_list = NULL;
    groupinfo *eating_list = NULL;
    pthread_mutex_t eating_mutex;
    pthread_mutex_init(&eating_mutex, NULL);
    restaurantstate rst;
    restaurantstate_init(&rst, num_tables);
    sem_t done_sem;
    if (sem_init(&done_sem, 0, 0)) {
        fprintf(stderr, "sem_init() failed: %s\n", strerror(errno));
        abort();
    }

    while (1) {
        int res;
        while (1) {
            char str[1024];
            res = scanf(" %1023s", str);
            if (res < 1 || strcmp(str, ".") == 0) break;
            cmd_type type;
            if (strcmp(str, "Enter") == 0) type = CMD_ENTER;
            else if (strcmp(str, "Leave") == 0) type = CMD_LEAVE;
            else {
                fprintf(stderr, "Invalid command \"%s\"!\n", str);
                abort();
            }
            cmdlist *new_cmd = malloc(sizeof(cmdlist));
            assert_malloc_succeeded(new_cmd);
            int id;
            scanf("%d", &id);
            new_cmd->type = type;
            new_cmd->group_id = id;
            if (type == CMD_ENTER) {
                int size;
                scanf("%d", &size);
                if (size < 1 || size > 5) {
                    fprintf(stderr, "Invalid group size \"%d\"!\n", size);
                    abort();
                }
                new_cmd->enter_data.group_size = size;
            }
            new_cmd->next = cmds;
            cmds = new_cmd;
        }
        atomic_uint enqueue_counter;
        atomic_init(&enqueue_counter, 0);
        unsigned num_threads = cmdlist_size(cmds);
        unsigned expected_num_enqueued = 0;
        if (num_threads) {
            // these stuff to help ensure that threads start at the same time,
            // in the hope of triggering some race conditions.
            busywaiter waiter;
            busywaiter_init(&waiter);

            for (cmdlist *it = cmds; it; it = it->next) {
                switch (it->type) {
                    case CMD_ENTER: {
                        restaurantstate_enqueue(&rst, it->enter_data.group_size);
                        groupinfo *info = malloc(sizeof(groupinfo));
                        assert_malloc_succeeded(info);
                        info->group_id = it->group_id;
                        info->group_size = it->enter_data.group_size;
                        info->waiter = &waiter;
                        it->enter_data.enqueued = false;
                        info->enqueue_reporter = &it->enter_data.enqueued;
                        info->enqueue_counter = &enqueue_counter;
                        info->eating_list = &eating_list;
                        info->eating_mutex = &eating_mutex;
                        info->done_sem = &done_sem;
                        int err;
                        if ((err = pthread_create(&(info->thread), NULL, &run_group, info))) {
                            fprintf(stderr, "pthread_create() failed: %d\n", err);
                            abort();
                        }
                        //fprintf(output_file, "Enter %d %d\n", info->group_id, info->group_size);
                        ++expected_num_enqueued;
                        break;
                    }
                    case CMD_LEAVE: {
                        groupinfo *info = groupinfo_find_and_extract(&real_eating_list, it->group_id);
                        if (!info) {
                            // In this situation, the student code probably has a bug that caused our group to not get seated when it should have been.
                            // printf("Test case wants group %d to leave, but this group is not currently seated... Test case failed\n", it->group_id);
                            // TODO this is broken... we need an adaptive grader
                            fprintf(output_file, "A\n"); // magic symbol to mean this error
                            return 0;
                        }
                        restaurantstate_leave(&rst, info->group_size, info->table_id);
                        it->leave_data.info = info;
                        info->waiter = &waiter;
                        sem_post(&info->leave_sem);
                        break;
                    }
                    default: {
                        assert(false);
                    }
                }
            }
            busywaiter_main_wait(&waiter, num_threads);
            busywaiter_destroy(&waiter);
        }
        usleep(10000); // sleep for 10ms (during grading, we will wait for at least as many groups as we expect)
        struct timespec three_seconds_later;
        clock_gettime(CLOCK_REALTIME, &three_seconds_later);
        three_seconds_later.tv_sec += 3;
        while (atomic_load_explicit(&enqueue_counter, memory_order_acquire) != expected_num_enqueued) { // wait until all groups are enqueued
            struct timespec curr_time;
            clock_gettime(CLOCK_REALTIME, &curr_time);
            if (curr_time.tv_sec > three_seconds_later.tv_sec || (curr_time.tv_sec == three_seconds_later.tv_sec && curr_time.tv_nsec > three_seconds_later.tv_nsec)) {
                fprintf(output_file, "D\n"); // magic symbol to mean a timeout error
                return 0;
            }
        }
        while (cmds) {
            switch (cmds->type) {
                case CMD_ENTER: {
                    if (!cmds->enter_data.enqueued) {
                        //printf("Some other group called on_enqueue() twice, because group %d didn't call on_enqueue()... Test case failed\n", cmds->group_id);
                        fprintf(output_file, "B\n"); // magic symbol to mean this error
                        return 0;
                    }
                    //fprintf(output_file, "Enqueue %d\n", cmds->group_id);
                    break;
                }
                case CMD_LEAVE: {
                    groupinfo *info = cmds->leave_data.info;
                    int pthread_ret = pthread_timedjoin_np(info->thread, NULL, &three_seconds_later);
                    if (pthread_ret == ETIMEDOUT) {
                        fprintf(output_file, "E\n"); // magic symbol to mean a timeout error
                        return 0;
                    }
                    else if (pthread_ret) {
                        fprintf(stderr, "pthread_join() failed: %d\n", pthread_ret);
                        abort();
                    }
                    //fprintf(output_file, "Leave %d\n", info->group_id);
                    free(info);
                    break;
                }
                default: {
                    assert(false);
                }
            }
            cmdlist *tmp = cmds->next;
            free(cmds);
            cmds = tmp;
        }
        int sem_code = 0;
        while (sem_trywait(&done_sem) == 0 || (!restaurantstate_iscomplete(&rst) && (sem_code = sem_timedwait(&done_sem, &three_seconds_later)) == 0)) {
            pthread_mutex_lock(&eating_mutex);
            assert(eating_list);
            fprintf(output_file, "Seated %d %d\n", eating_list->group_id, eating_list->table_id);
            restaurantstate_seated(&rst, eating_list->group_size, eating_list->table_id);
            groupinfo *next_eating_list = eating_list->next;
            eating_list->next = real_eating_list;
            real_eating_list = eating_list;
            eating_list = next_eating_list;
            pthread_mutex_unlock(&eating_mutex);
        }
        if (sem_code == -1 && errno == ETIMEDOUT) {
            fprintf(output_file, "C\n"); // magic symbol to mean a timeout error
            return 0;
        }
        if (res != EOF) {
            fprintf(output_file, ".\n");
        }
        else {
            break;
        }
    }
    pthread_mutex_destroy(&eating_mutex);

    restaurant_destroy();

    fclose(output_file);
}
