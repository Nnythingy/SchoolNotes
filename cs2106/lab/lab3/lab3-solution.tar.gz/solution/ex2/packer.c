#include <semaphore.h>
#include <stddef.h>

#include "packer.h"

typedef struct {
    sem_t mtx;
    sem_t waiter;
    sem_t turnstile;
    int *id;
} data_barrier;

data_barrier barr[3];

void packer_init(void) {
    for (int i = 0; i < 3; ++i){
        sem_init(&barr[i].mtx, 0, 1);
        sem_init(&barr[i].waiter, 0, 0);
        sem_init(&barr[i].turnstile, 0, 1);
        barr[i].id = NULL;
    }
}

void packer_destroy(void) {
    for (int i = 0; i < 3; ++i){
        sem_destroy(&barr[i].mtx);
        sem_destroy(&barr[i].waiter);
        sem_destroy(&barr[i].turnstile);
    }
}

int pack_ball(int colour, int id) {
    data_barrier *b = &barr[colour - 1];
    int other_id;
    sem_wait(&b->mtx);
    if (b->id) { // other thread is already waiting
        other_id = *b->id;
        *b->id = id;
        b->id = NULL;
        sem_post(&b->waiter);
        sem_post(&b->mtx);
    }
    else {
        other_id = id;
        b->id = &other_id;
        sem_wait(&b->turnstile);
        sem_post(&b->mtx);
        sem_wait(&b->waiter);
        sem_post(&b->turnstile);
    }
    return other_id;
}
