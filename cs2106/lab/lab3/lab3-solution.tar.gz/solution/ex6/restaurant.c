#include <semaphore.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stddef.h>

#include "restaurant.h"

typedef struct table_node_t {
    struct table_node_t *prev, *next;
} table_node_t;

typedef struct {
    table_node_t base;
} table_list_t;

typedef struct {
    table_node_t base;
    int table_id;
    int num_seats;
    int num_empty_seats;
} table_t;

void table_list_init(table_list_t *list) {
    list->base.next = &list->base;
    list->base.prev = &list->base;
}

void table_list_destroy(table_list_t *list) {
    (void) list;
}

// pops and returns a table if exists, otherwise returns NULL
table_t *table_list_try_get_table(table_list_t *list) {
    table_node_t *curr = list->base.next;
    if (curr == &list->base) return NULL;
    table_node_t *next = curr->next;
    list->base.next = next;
    next->prev = &list->base;
    return (table_t *)((char *)curr - offsetof(table_t, base));
}

// add table to set
void table_list_add_table(table_list_t *list, table_t *table) {
    table_node_t *next = list->base.next;
    list->base.next = &table->base;
    next->prev = &table->base;
    table->base.prev = &list->base;
    table->base.next = next;
}

// remove table from set
void table_list_remove_table(table_t *table) {
    table_node_t *prev = table->base.prev;
    table_node_t *next = table->base.next;
    prev->next = next;
    next->prev = prev;
}

typedef struct elem_t {
    unsigned global_idx; // globally assigned monotonically increasing index, this specifies the order in the global combined queue
    sem_t wait_sem;
    table_t *table;
    struct elem_t *next;
} elem_t;

table_t *table_buf;
table_list_t tables_totally_empty[5], tables_partially_empty[5];
sem_t mtx;
elem_t *queues[5];
elem_t **queue_lasts[5];
unsigned global_idx;

void restaurant_init(int num_tables[5]) {
    for (int i = 0; i < 5; ++i) {
        table_list_init(&tables_totally_empty[i]);
        table_list_init(&tables_partially_empty[i]);
        queues[i] = NULL;
        queue_lasts[i] = &queues[i];
    }
    int total_tables = 0;
    for (int i = 0; i < 5; ++i) {
        total_tables += num_tables[i];
    }
    table_buf = malloc(total_tables * sizeof(table_t));
    int table_id_next = 0;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < num_tables[i]; ++j) {
            table_t *table = &table_buf[table_id_next];
            table->table_id = table_id_next;
            table->num_empty_seats = table->num_seats = i + 1;
            table_list_add_table(&tables_totally_empty[i], table);
            ++table_id_next;
        }
    }
    sem_init(&mtx, 0, 1);
    global_idx = 0;
}

void restaurant_destroy(void) {
    sem_destroy(&mtx);
    for (int i = 0; i < 5; ++i) {
        table_list_destroy(&tables_totally_empty[i]);
        table_list_destroy(&tables_partially_empty[i]);
    }
    free(table_buf);
}

int request_for_table(group_state *state, int num_people) {
    state->num_people = num_people;
    int index = num_people - 1;

    sem_wait(&mtx);

    // find an available table that is totally empty
    for (int i = index; i < 5; ++i) {
        table_t *table = table_list_try_get_table(&tables_totally_empty[i]);
        if (table) {
            // got a totally empty table, we should assign this table to this group
            state->table = table;
            table->num_empty_seats -= num_people;
            if (table->num_empty_seats) {
                table_list_add_table(&tables_partially_empty[table->num_empty_seats - 1], table);
            }
            sem_post(&mtx);
            on_enqueue();
            return table->table_id;
        }
    }
    
    // find an available table that is partially empty
    for (int i = index; i < 5; ++i) {
        table_t *table = table_list_try_get_table(&tables_partially_empty[i]);
        if (table) {
            // got a partially empty table, we should assign this table to this group
            state->table = table;
            table->num_empty_seats -= num_people;
            if (table->num_empty_seats) {
                table_list_add_table(&tables_partially_empty[table->num_empty_seats - 1], table);
            }
            sem_post(&mtx);
            on_enqueue();
            return table->table_id;
        }
    }

    // no valid tables, we have to queue up
    unsigned my_global_idx = global_idx++;
    elem_t elem;
    elem.global_idx = my_global_idx;
    sem_init(&elem.wait_sem, 0, 0);
    elem.next = NULL;
    *queue_lasts[index] = &elem;
    queue_lasts[index] = &elem.next;
    sem_post(&mtx);
    on_enqueue();
    sem_wait(&elem.wait_sem); // wait until it's my turn to go
    // the poster should already decouple my elem from the queue for me, and give me the table, and put it in the partially empty list if there are empty seats remaining

    sem_destroy(&elem.wait_sem);
    state->table = elem.table;

    return elem.table->table_id;
}

void leave_table(group_state *state) {
    sem_wait(&mtx);

    table_t *table = (table_t *)state->table;

    // make our seats empty again
    if (table->num_empty_seats) {
        table_list_remove_table(table);
    }
    table->num_empty_seats += state->num_people;

    while (true) {
        int earliest_index = -1;
        for (int i = 0; i < table->num_empty_seats; ++i) {
            if (queues[i]) {
                if (earliest_index == -1 || queues[i]->global_idx < queues[earliest_index]->global_idx) {
                    earliest_index = i;
                }
            }
        }
        if (earliest_index != -1) {
            // there is a group that wants our table, remove it from the queue
            elem_t *elem = queues[earliest_index];
            queues[earliest_index] = queues[earliest_index]->next;
            if (!queues[earliest_index]) queue_lasts[earliest_index] = &queues[earliest_index];

            // give this group my table
            elem->table = table;
            table->num_empty_seats -= earliest_index + 1;

            // wake it up
            sem_post(&elem->wait_sem);

            if (!table->num_empty_seats) break;
        }
        else break;
    }
    
    // nobody else wants our table, so put our table back on the free list
    if (table->num_empty_seats == table->num_seats) {
        table_list_add_table(&tables_totally_empty[table->num_empty_seats - 1], table);
    }
    else if (table->num_empty_seats > 0) {
        table_list_add_table(&tables_partially_empty[table->num_empty_seats - 1], table);
    }

    sem_post(&mtx);
}