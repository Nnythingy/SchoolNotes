#include <semaphore.h>
#include <stdlib.h>
#include <stdbool.h>

#include "restaurant.h"

typedef struct elem_t {
    unsigned global_idx; // globally assigned monotonically increasing index, this specifies the order in the global combined queue
    sem_t wait_sem;
    int num_seats_on_table;
    int table_id;
    struct elem_t *next;
} elem_t;

int *table_list[5];
int table_counts[5];
sem_t mtx;
elem_t *queues[5];
elem_t **queue_lasts[5];
unsigned global_idx;

void restaurant_init(int num_tables[5]) {
    int table_id_next = 0;
    for (int i = 0; i < 5; ++i) {
        table_list[i] = malloc(num_tables[i] * sizeof(int));
        for (int j = 0; j < num_tables[i]; ++j) {
            table_list[i][j] = table_id_next++;
        }
        queues[i] = NULL;
        queue_lasts[i] = &queues[i];
        table_counts[i] = num_tables[i];
    }
    sem_init(&mtx, 0, 1);
    global_idx = 0;
}

void restaurant_destroy(void) {
    sem_destroy(&mtx);
    for (int i = 0; i < 5; ++i) {
        free(table_list[i]);
    }
}

static bool has_table(int index) {
    return table_counts[index] != 0;
}

static int pop_table(int index) {
    --table_counts[index];
    int res = *table_list[index]++;
    return res;
}

static void push_table(int index, int table_id) {
    *--table_list[index] = table_id;
    ++table_counts[index];
}

int request_for_table(group_state *state, int num_people) {
    --num_people;

    int table_id;

    sem_wait(&mtx);

    // find an available table
    int i;
    for (i = num_people; i < 5; ++i) {
        if (has_table(i)) {
            // found a valid table
            table_id = pop_table(i);
            break;
        }
    }
    if (i != 5) {
        sem_post(&mtx);
        on_enqueue();
        state->num_seats_on_table = i;
        state->table_id = table_id;
    }
    else {
        // can't find any table... need to add myself to queue
        unsigned my_global_idx = global_idx++;
        elem_t elem;
        elem.global_idx = my_global_idx;
        sem_init(&elem.wait_sem, 0, 0);
        elem.next = NULL;
        *queue_lasts[num_people] = &elem;
        queue_lasts[num_people] = &elem.next;
        sem_post(&mtx);
        on_enqueue();
        sem_wait(&elem.wait_sem); // wait until it's my turn to go
        // the poster should already decouple my elem from the queue for me, and give me the table

        sem_destroy(&elem.wait_sem);
        table_id = elem.table_id; // set by the poster
        state->num_seats_on_table = elem.num_seats_on_table;
        state->table_id = elem.table_id;
    }

    return table_id;
}

void leave_table(group_state *state) {
    sem_wait(&mtx);
    int earliest_index = -1;
    for (int i = 0; i <= state->num_seats_on_table; ++i) {
        if (queues[i]) {
            if (earliest_index == -1 || queues[i]->global_idx < queues[earliest_index]->global_idx) {
                earliest_index = i;
            }
        }
    }
    if (earliest_index != -1) {
        // there is a group that wants our table, remove it from the queue
        elem_t *elem = queues[earliest_index];
        queues[earliest_index] = queues[earliest_index]->next;
        if (!queues[earliest_index]) queue_lasts[earliest_index] = &queues[earliest_index];

        // give this group my table
        elem->num_seats_on_table = state->num_seats_on_table;
        elem->table_id = state->table_id;

        // wake it up
        sem_post(&elem->wait_sem);
    }
    else {
        // nobody wants our table, so put our table back on the free list
        push_table(state->num_seats_on_table, state->table_id);
    }
    sem_post(&mtx);
}