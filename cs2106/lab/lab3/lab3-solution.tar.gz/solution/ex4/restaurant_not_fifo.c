#include <semaphore.h>
#include <stdlib.h>

#include "restaurant.h"

int *table_list[5];
sem_t wait_sems[5];
sem_t table_mtx[5];

static int pop_table(int index) {
    sem_wait(&table_mtx[index]);
    int res = *table_list[index]++;
    sem_post(&table_mtx[index]);
    return res;
}

static void push_table(int index, int table_id) {
    sem_wait(&table_mtx[index]);
    *--table_list[index] = table_id;
    sem_post(&table_mtx[index]);
}

void restaurant_init(int num_tables[5]) {
    int table_id_next = 0;
    for (int i = 0; i < 5; ++i) {
        table_list[i] = malloc(num_tables[i] * sizeof(int));
        for (int j = 0; j < num_tables[i]; ++j) {
            table_list[i][j] = table_id_next++;
        }
        sem_init(&wait_sems[i], 0, num_tables[i]);
        sem_init(&table_mtx[i], 0, 1);
    }
}

void restaurant_destroy(void) {
    for (int i = 0; i < 5; ++i) {
        sem_destroy(&table_mtx[i]);
        sem_destroy(&wait_sems[i]);
        free(table_list[i]);
    }
}

int request_for_table(group_state *state, int num_people) {
    --num_people;
    state->num_people = num_people;
    on_enqueue();
    sem_wait(&wait_sems[num_people]);
    int table_id = pop_table(num_people);
    state->table_id = table_id;
    return table_id;
}

void leave_table(group_state *state) {
    push_table(state->num_people, state->table_id);
    sem_post(&wait_sems[state->num_people]);
}