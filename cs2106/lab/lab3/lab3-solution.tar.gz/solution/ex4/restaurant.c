#include <semaphore.h>
#include <stdlib.h>
#include <stdbool.h>

#include "restaurant.h"

typedef struct {
    unsigned next_queue_num;
    unsigned enter_queue_num;
    unsigned queue_selector;
    sem_t mtx;
    sem_t queue;
    sem_t barrierenter;
    sem_t barrierexit;
} fifo_sem_t;

static void fifo_sem_init(fifo_sem_t *fsem, unsigned value) {
    fsem->next_queue_num = 0;
    fsem->enter_queue_num = value;
    fsem->queue_selector = 0;
    sem_init(&fsem->mtx, 0, 1);
    sem_init(&fsem->queue, 0, 0);
    sem_init(&fsem->barrierenter, 0, 0);
    sem_init(&fsem->barrierexit, 0, 0);
}

static void fifo_sem_destroy(fifo_sem_t *fsem) {
    sem_destroy(&fsem->barrierexit);
    sem_destroy(&fsem->barrierenter);
    sem_destroy(&fsem->queue);
    sem_destroy(&fsem->mtx);
}

static bool circular_less(unsigned x, unsigned y) {
    return (int)(y - x) > 0;
}

static void fifo_sem_wait(fifo_sem_t *fsem) {
    sem_wait(&fsem->mtx);
    unsigned my_queue_num = fsem->next_queue_num++;
    bool need_wait = !circular_less(my_queue_num, fsem->enter_queue_num);
    sem_post(&fsem->mtx);
    on_enqueue();
    if (need_wait) {
        while (true) {
            sem_wait(&fsem->queue);
            bool to_return = circular_less(my_queue_num, fsem->enter_queue_num);
            sem_post(&fsem->barrierenter);
            if (to_return) return;
            sem_wait(&fsem->barrierexit);
        }
    }
}

static void fifo_sem_post(fifo_sem_t *fsem) {
    sem_wait(&fsem->mtx);
    if (circular_less(fsem->enter_queue_num, fsem->next_queue_num)) {
        int tmp_enter_queue_num = fsem->enter_queue_num;
        ++fsem->enter_queue_num;
        for (unsigned i = tmp_enter_queue_num; i != fsem->next_queue_num; ++i) {
            sem_post(&fsem->queue);
        }
        for (unsigned i = tmp_enter_queue_num; i != fsem->next_queue_num; ++i) {
            sem_wait(&fsem->barrierenter);
        }
        for (unsigned i = fsem->enter_queue_num; i != fsem->next_queue_num; ++i) {
            sem_post(&fsem->barrierexit);
        }
    }
    else {
        ++fsem->enter_queue_num;
    }
    sem_post(&fsem->mtx);
}

int *table_list[5];
fifo_sem_t wait_sems[5];
sem_t table_mtx[5];

static int pop_table(int index) {
    sem_wait(&table_mtx[index]);
    int res = *table_list[index]++;
    sem_post(&table_mtx[index]);
    return res;
}

static void push_table(int index, int table_id) {
    sem_wait(&table_mtx[index]);
    *--table_list[index] = table_id;
    sem_post(&table_mtx[index]);
}

void restaurant_init(int num_tables[5]) {
    int table_id_next = 0;
    for (int i = 0; i < 5; ++i) {
        table_list[i] = malloc(num_tables[i] * sizeof(int));
        for (int j = 0; j < num_tables[i]; ++j) {
            table_list[i][j] = table_id_next++;
        }
        fifo_sem_init(&wait_sems[i], num_tables[i]);
        sem_init(&table_mtx[i], 0, 1);
    }
}

void restaurant_destroy(void) {
    for (int i = 0; i < 5; ++i) {
        sem_destroy(&table_mtx[i]);
        fifo_sem_destroy(&wait_sems[i]);
        free(table_list[i]);
    }
}

int request_for_table(group_state *state, int num_people) {
    --num_people;
    state->num_people = num_people;
    fifo_sem_wait(&wait_sems[num_people]);
    int table_id = pop_table(num_people);
    state->table_id = table_id;
    return table_id;
}

void leave_table(group_state *state) {
    push_table(state->num_people, state->table_id);
    fifo_sem_post(&wait_sems[state->num_people]);
}