#include "userswap.h"

#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <unistd.h>

#include "seccomp.h"

#define EPRINT(...) fprintf(stderr, __VA_ARGS__)

#define DPRINT(...)                                                                                \
  do {                                                                                             \
    if (!debug_print)                                                                              \
      break;                                                                                       \
    EPRINT(__VA_ARGS__);                                                                           \
  } while (0)

static volatile _Bool write_seen = 0;

ssize_t __real_write(int fd, const void *buf, size_t count);
ssize_t __real_pwrite(int fd, const void *buf, size_t count, off_t offset);

ssize_t __wrap_write(int fd, const void *buf, size_t count) {
  write_seen = 1;
  return __real_write(fd, buf, count);
}

ssize_t __wrap_pwrite(int fd, const void *buf, size_t count, off_t offset) {
  write_seen = 1;
  return __real_pwrite(fd, buf, count, offset);
}

void *__wrap_malloc(size_t size) {
  return calloc(1, size);
}

enum op {
  // response = read size_t
  op_read8,
  // response = nil
  op_write8,
  // response = read char
  op_read1,
  // response = nil
  op_write1,
  // response = allocated address
  op_alloc,
  // response = allocated address
  op_map,
  // response = nil
  op_free,
  // response = nil
  op_lorm,
  // response = fd
  op_open,
  // response = nil
  op_close,
  // no response, duh
  op_exit
};

struct input {
  void *addr;
  union {
    size_t arg8;
    char arg1;
  };
  int fd;
  enum op op;
};
_Static_assert(sizeof(struct input) == 24, "size of struct input wrong");
_Static_assert(offsetof(struct input, op) == 20, "offset of struct input.op wrong");

struct response {
  union {
    void *addr;
    size_t size_t;
    char char_;
    int fd;
  };
  size_t write_seen;
};
_Static_assert(sizeof(struct response) == 16, "size of struct response wrong");

static int read_complete(const int fd, void *const buf, const size_t size) {
  char *const bufp = buf;
  size_t total_read = 0;
  while (total_read < size) {
    ssize_t this_read = read(fd, bufp + total_read, size - total_read);
    if (this_read == -1) {
      perror("read");
      return -1;
    } else if (this_read == 0) {
      fprintf(stderr, "unexpected EOF, %zu/%zu\n", total_read, size);
      return -1;
    }
    total_read += (size_t)this_read;
  }
  return 0;
}

static int write_complete(const int fd, const void *const buf, size_t size) {
  const char *const bufp = buf;
  size_t total_write = 0;
  while (total_write < size) {
    ssize_t this_write = write(fd, bufp + total_write, size - total_write);
    if (this_write == -1) {
      perror("write");
      return -1;
    }
    total_write += (size_t)this_write;
  }
  return 0;
}

int main(int argc, char *argv[]) {
  {
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ALLOW);
    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(mmap), 1,
                         SCMP_A3_32(SCMP_CMP_MASKED_EQ, MAP_ANONYMOUS, 0)))
      goto seccomp_fail;
    if (seccomp_load(ctx))
      goto seccomp_fail;
    seccomp_release(ctx);
  }

  prctl(PR_SET_PDEATHSIG, SIGKILL);
  _Bool debug_print = !!getenv("US_RUNNER_DEBUG");
  setbuf(stderr, NULL);

  int err;
  int ifd = 0, ofd = 1;
  if (argc >= 2) {
    ifd = atoi(argv[1]);
  }
  if (argc >= 3) {
    ofd = atoi(argv[2]);
  } else {
    ofd = ifd ? ifd : 1;
  }

  struct input input;
  struct response response;
  while (!read_complete(ifd, &input, sizeof(input))) {
    write_seen = 0;
    switch (input.op) {
    // response = read size_t
    case op_read8:
      DPRINT("op_read8(%p)", input.addr);
      response.size_t = *(size_t *)input.addr;
      DPRINT(" == %zu 0x%zx\n", response.size_t, response.size_t);
      break;

    // response = nil
    case op_write8:
      DPRINT("op_write8(%p, %zu 0x%zx)", input.addr, input.arg8, input.arg8);
      *(size_t *)input.addr = input.arg8;
      DPRINT(" completed\n");
      break;

    // response = read char
    case op_read1:
      DPRINT("op_read1(%p)", input.addr);
      response.char_ = *(char *)input.addr;
      DPRINT(" == %d %x\n", response.char_, response.char_);
      break;

    // response = nil
    case op_write1:
      DPRINT("op_write1(%p, %d 0x%x)", input.addr, input.arg1, input.arg1);
      *(char *)input.addr = input.arg1;
      DPRINT(" completed\n");
      break;

    // response = allocated address
    case op_alloc:
      DPRINT("op_alloc(0x%zx)", input.arg8);
      response.addr = userswap_alloc(input.arg8);
      DPRINT(" == %p\n", response.addr);
      break;

    // response = allocated address
    case op_map:
      DPRINT("op_map(FD %d, 0x%zx)", input.fd, input.arg8);
      response.addr = userswap_map(input.fd, input.arg8);
      DPRINT(" == %p\n", response.addr);
      break;

    // response = nil
    case op_free:
      DPRINT("op_free(%p)", input.addr);
      userswap_free(input.addr);
      DPRINT(" completed\n");
      break;

    // response = nil
    case op_lorm:
      DPRINT("op_lorm(%zu 0x%zx)", input.arg8, input.arg8);
      userswap_set_size(input.arg8);
      DPRINT(" completed\n");
      break;

    // response = fd
    case op_open: {
      char filename_buf[256] = {0};
      DPRINT("op_open(");
      if (input.fd < 0) {
        EPRINT("op_open negative filename size\n");
        break;
      }
      if ((size_t)input.fd + 1 > sizeof(filename_buf)) {
        EPRINT("op_open filename too large\n");
        break;
      }
      if (read_complete(ifd, filename_buf, input.fd)) {
        break;
      }
      filename_buf[input.fd] = 0;
      DPRINT("\"%s\")", filename_buf);
      response.fd = open(filename_buf, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
      DPRINT(" = FD %d\n", response.fd);
      if (response.fd == -1) {
        perror("open");
      }
      break;
    }

    // response = nil
    case op_close:
      DPRINT("op_close(FD %d)", input.fd);
      close(input.fd);
      DPRINT("completed\n");
      break;

    case op_exit:
      DPRINT("op_exit. Bye bye!\n");
      _exit(0);
      break;
    }

    response.write_seen = write_seen;
    if (write_complete(ofd, &response, sizeof(response))) {
      break;
    }
  }

  return 1;

seccomp_fail:
  EPRINT("failed to initialise seccomp context: %d\n", err);
  _exit(1);
}
