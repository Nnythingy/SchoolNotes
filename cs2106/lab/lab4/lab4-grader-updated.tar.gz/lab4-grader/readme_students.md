# Lab 4 grading

## Testcases

Please read the remarks (the grading result) in conjunction with the grading
scheme at the end of this document, and the testcases in the `tc/` folder in `lab4-grader.tar.gz`.

This is the syntax of the testcases:

- size: a decimal (no prefix) or hex (prefixed by `0x`) number; can be multiplied by page size (suffixed by `pg`)
- aname: Allocation name; a name used to refer to an allocation in the testcase script
- fdname: File descriptor name; a name used to refer to a file descriptor in the script
- alloc aname size: allocate memory of size `size` and assign it to the name `aname` (call `userswap_alloc(size)`)
- map aname fdname size: map the file in `fdname` up to size `size` and assign the mapping to the name `aname` (call `userswap_map(fd, size)`)
- read8 aname offset: read the 64-bit value (unsigned long) at offset `offset` into allocation `aname`
- read1 aname offset: read the byte at offset `offset` into allocation `aname`
- write8 aname offset value: write the 64-bit value `value` (unsigned long) at offset `offset` into allocation `aname`
- write1 aname offset value: write the byte `value` at offset `offset` into allocation `aname`
- free aname: free the allocation `aname` (call `userswap_free(address)`)
- lorm size: set the LORM to `size` bytes
- mkfile fdname size: create a temporary file of size `size`, fill it with random data, and open it in the runner; then assign the FD to the name `fdname`
- close fdname: close the FD `fdname`
- mappingassert on|off: enable/disable the checking of the existence of allocations and their permissions (on by default)
- readassert on|off: enable/disable the verification of read results (on by default)
- writeassert on|off: enable/disable the verification of writes (i.e. whether unexpected writes to files results in an error) (off by default)
- checkmapping aname: check the existence (but not the permissions) of the given allocation
- randread aname count: do `count` reads from random locations in the allocation
- randwrite aname count: do `count` writes to random locations in the allocation
- randrw aname count: do `count` reads/writes (in total, randomly decided) from/to random locations in the allocation
- shufread aname startpage count: do one read each to a random location in each page starting from page index `startpage` and going for `count` pages, in a random order
- shufwrite aname startpage count: do one write each to a random location in each page starting from page index `startpage` and going for `count` pages, in a random order
- shufrw aname startpage count: do one read or write (randomly decided) each to a random location in each page starting from page index `startpage` and going for `count` pages, in a random order
- seqread aname startpage count: do one read each to a random location in each page starting from page index `startpage` and going for `count` pages, in sequential order
- seqwrite aname startpage count: do one write each to a random location in each page starting from page index `startpage` and going for `count` pages, in sequential order
- seqrw aname startpage count: do one read or write (randomly decided) each to a random location in each page starting from page index `startpage` and going for `count` pages, in sequential order
- randinit aname: fill the allocation with random bytes
- checkfile fdname: verify the size and contents of the file
- checkhandler: check the presence of the SIGSEGV handler
- expectcrash: expect the testee to crash
- nomadvise: do not check that MADV_DONTNEED has been called on eviction (used primarily for Ex1-2 testcases)
- checkswapfile: verify that the swapfile is not larger than allowed
- randompageoffset: make {shuf,seq}{read,write,rw} use random page offsets (instead of always 0)

## Explanation of certain errors

> Requirement(s) Xy not met

Refer to the grading scheme for an explanation of requirements.

> error: exited with signal SIGSYS (Bad system call)

This means that you used `mmap` without specifying `MAP_ANONYMOUS` in the flags.

> error: at addr 0 in alloc a2, expected page permissions X but got Y

At the end of each read/write, the grader checks the mappings in the kernel (using /proc/pid/maps), and expects the following:

- freed page: unmapped
- nonresident page: none
- clean page: readonly
- dirty page: readwrite

> error: kernel page at addr 0 in alloc a1 not freed after page evicted; missing MADV_DONTNEED?

This means that the page was evicted, but it was still allocated a physical page in the kernel, likely because your program did not apply MADV_DONTNEED to the page.

> error: expected crash but testee did not crash

This means that in testcase 1e, your program did not remove the SIGSEGV handler on a SIGSEGV to an uncontrolled region.

> error: testee stopped receiving commands

This means that your program disconnected from the grader before the testcase was complete. Most likely, your program crashed or exited, but we did not see the process exit (due to `wait(WNOHANG)`).

> error: testee exited prematurely with exit code 1

The same as above, but we saw the process exit.

> error: unexpected write(s) seen

This means your program made write(s) to files or the swapfile when unnecessary (e.g. during an eviction of a clean page).

> error: userswap_alloc(1024) returned non page-aligned address 7ffd0ee47f08, unusable

This means that your `userswap_alloc` or `map` returned a non-page-aligned address (last three nybbles nonzero). `mmap` will never return such an address. Either you accidentally returned a pointer to the address, or you might have forgotten to initialise some local variable.

> error: expected ... when reading u64 a1+..., got ...

This means that the wrong value was seen when reading from an allocation. Most likely your program did not restore the page's contents correctly.

## Using the grader

To use the grader:

1. Place your solution C file in the `s/m/` directory.
2. Run `./run_pretty.sh`.

Although the grader binary is provided (`grader-bin`), the source (in Rust) is
available in the `grader/` directory. You will need the Rust toolchain to compile
it if you wish to do so.
