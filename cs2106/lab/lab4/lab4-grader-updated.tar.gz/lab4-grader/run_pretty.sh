#!/bin/bash

SCRIPT_DIR="$(dirname "$(realpath -s "${BASH_SOURCE[0]}")")"
cd "$SCRIPT_DIR"

make s

for s in s/m/*.run; do
  for tc in tc/*; do
    ./run_one.sh "$s" "$tc"
  done
done

PRETTY=1 ./collate.py
