#!/usr/bin/env python3

from collections import namedtuple
import csv, os, sys

TC = namedtuple('TC', ['name', 'score', 'deps'])
TR = namedtuple('TR', ['passed', 'score', 'output'])

TESTCASES = [
  TC('1a', 3, []),
  TC('1b', 1, ['1a']),
  TC('1c', 3, ['1a']),
  TC('1d', 2, []),
  TC('1e', 2, ['1d']),
  TC('1f', 2, ['1b', '1d']),
  TC('1g', 2, ['1b', '1d']),
  TC('1h', 3, []),
  TC('1i', 2, ['1b', '1d']),
  TC('2a', 2, ['1f']),
  TC('2b', 1, ['1f']),
  TC('2c', 2, ['1f']),
  TC('2d', 2, ['2a']),
  TC('2e', 3, ['2a']),
  TC('3a', 1, []),
  TC('3b', 4, ['3a']),
  TC('3c', 1, ['3b']),
  TC('3d', 1, ['3b']),
  TC('3e', 1, ['3b']),
  TC('3f', 2, ['3a']),
  TC('3g', 5, ['3a']),
  TC('3h', 1, ['3b']),
  TC('3i', 1, ['3b']),
  TC('3j', 2, ['3a']),
  TC('3k', 1, []),
  TC('4a', 2, []),
  TC('4b', 3, ['4a']),
  TC('4c', 1, []),
  TC('4d', 1, []),
  TC('4e', 2, ['3a']),
  TC('4f', 2, []),
  TC('4g', 4, []),
  TC('4h', 5, []),
  TC('5a', 3, ['3a']),
  TC('5b', 1, ['5a']),
  TC('5c', 1, ['5a']),
  TC('5d', 5, []),
]

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
os.chdir(SCRIPT_DIR)
try:
  with open('demoed', 'r') as f:
    demoed = set(f.read().strip().split('\n'))
except:
  demoed = set()
submissions = [s[:-4] for s in os.listdir('s/m') if s.endswith('.run')]
results = dict((s, {}) for s in submissions)

def do_one(submission, tc):
  global results, TR
  sub_results = results[submission]
  with open(f'r/m/{submission}-{tc.name}', 'r') as f:
    output = f.read()
  failed_deps = [t for t in tc.deps if not sub_results[t].passed]
  passed = output.startswith('passed\n')
  if len(failed_deps) > 0:
    sub_results[tc.name] = TR(False, 0, f"Requirement(s) {', '.join(failed_deps)} not met")
  elif passed:
    sub_results[tc.name] = TR(True, tc.score, None)
  else:
    output = output[7:].split('\n')
    orig_lines = len(output)
    if orig_lines > 3:
      output = output[:3]
      output.append(f'({orig_lines - 3} more errors)')
    output = '\n'.join(output).strip()
    sub_results[tc.name] = TR(False, 0, output)

def do_submission(submission):
  global TESTCASES
  for tc in TESTCASES:
    do_one(submission, tc)

def format_submission(submission):
  global results
  ex1_total = 0
  total = 0
  remarks = []
  if submission in demoed:
    remarks.append("Demoed.")
    ex1_total += 10
  for tcname, tr in results[submission].items():
    if tr.passed:
      if tcname.startswith('1'):
        ex1_total += tr.score
      else:
        total += tr.score
    else:
      remarks.append(f"{tcname} failed:")
      remarks.append(tr.output)
      remarks.append("")
  total += min(ex1_total, 20)
  return [submission, total / 10, "", '\n'.join(remarks).strip()]

if os.environ.get('PRETTY'):
  for submission in submissions:
    do_submission(submission)
    [submission, score, _, remarks] = format_submission(submission)
    print(f"Submission {submission}: {score}/8")
    print(remarks)
    print()
else:
  csvwriter = csv.writer(sys.stdout)
  csvwriter.writerow(['STUDENT_NUMBER', 'MARKS', 'MODERATION', 'REMARKS'])
  for submission in submissions:
    do_submission(submission)
    csvwriter.writerow(format_submission(submission))
