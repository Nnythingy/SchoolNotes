#!/bin/bash

SCRIPT_DIR="$(dirname "$(realpath -s "${BASH_SOURCE[0]}")")"
GRADER="$SCRIPT_DIR/grader-bin"
TESTEE="$(realpath "$1")"
TESTCASE="$(realpath "$2")"
OUTPUT="$SCRIPT_DIR/r/m/$(basename "$TESTEE" .run)-$(basename "$TESTCASE")"

if [ -e "$OUTPUT" ]; then
  exit
fi

RUNDIR="$(mktemp -d -p /dev/shm)"
mkdir -p "$(dirname "$OUTPUT")"

cd "$RUNDIR"

mkdir cwd
cd cwd

timeout -v -s KILL 30s "$GRADER" "$TESTEE" < "$TESTCASE" > "$RUNDIR/out" 2> "$RUNDIR/err"
EXITSTATUS=$?
case $EXITSTATUS in
  0)
    echo "passed" > "$OUTPUT";;
  137)
    echo "timed out (30s)" >> "$RUNDIR/out";&
  *)
    echo "failed" > "$OUTPUT"
    cat "$RUNDIR/out" >> "$OUTPUT"
    cp "$RUNDIR/err" "$OUTPUT-err";;
esac

cd "$SCRIPT_DIR"

rm -rf "$RUNDIR"
