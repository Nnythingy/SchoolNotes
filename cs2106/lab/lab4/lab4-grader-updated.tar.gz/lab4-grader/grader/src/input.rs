use std::str::FromStr;

use lazy_static::lazy_static;
use regex::Regex;

use crate::{Address, Op};

lazy_static! {
    static ref R_READ8: Regex =
        Regex::new(r"^read8 (?P<name>[[:alnum:]]+) (?P<offset>[x[[:xdigit:]]]+(pg)?)$")
            .expect("failed to create regex");
    static ref R_WRITE8: Regex = Regex::new(
        r"^write8 (?P<name>[[:alnum:]]+) (?P<offset>[x[[:xdigit:]]]+(pg)?) (?P<value>[x[[:xdigit:]]]+)$"
    )
    .expect("failed to create regex");
    static ref R_READ1: Regex =
        Regex::new(r"^read1 (?P<name>[[:alnum:]]+) (?P<offset>[x[[:xdigit:]]]+(pg)?)$")
            .expect("failed to create regex");
    static ref R_WRITE1: Regex = Regex::new(
        r"^write1 (?P<name>[[:alnum:]]+) (?P<offset>[x[[:xdigit:]]]+(pg)?) (?P<value>[x[[:xdigit:]]]+)$"
    )
    .expect("failed to create regex");
    static ref R_ALLOC: Regex =
        Regex::new(r"^alloc (?P<name>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+(pg)?)$")
            .expect("failed to create regex");
    static ref R_MAP: Regex = Regex::new(
        r"^map (?P<name>[[:alnum:]]+) (?P<fdname>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+(pg)?)$"
    )
    .expect("failed to create regex");
    static ref R_FREE: Regex =
        Regex::new(r"^free (?P<name>[[:alnum:]]+)$").expect("failed to create regex");
    static ref R_LORM: Regex =
        Regex::new(r"^lorm (?P<size>[x[[:xdigit:]]]+(pg)?)$").expect("failed to create regex");
    static ref R_MKFILE: Regex = Regex::new(r"^mkfile (?P<fdname>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+(pg)?)$")
        .expect("failed to create regex");
    static ref R_CLOSE: Regex =
        Regex::new(r"^close (?P<fdname>[[:alnum:]]+)$").expect("failed to create regex");
    static ref R_MAPPINGASSERT: Regex =
        Regex::new(r"^mappingassert (?P<onoff>on|off)$").expect("failed to create regex");
    static ref R_CHECKMAPPING: Regex =
        Regex::new(r"^checkmapping (?P<name>[[:alnum:]]+)$").expect("failed to create regex");
    static ref R_RANDREAD: Regex = Regex::new(r"^randread (?P<name>[[:alnum:]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");
    static ref R_RANDWRITE: Regex =
        Regex::new(r"^randwrite (?P<name>[[:alnum:]]+) (?P<count>[x[[:xdigit:]]]+)$")
            .expect("failed to create regex");
    static ref R_RANDRW: Regex = Regex::new(r"^randrw (?P<name>[[:alnum:]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");

    static ref R_SHUFREAD: Regex = Regex::new(r"^shufread (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");
    static ref R_SHUFWRITE: Regex =
        Regex::new(r"^shufwrite (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
            .expect("failed to create regex");
    static ref R_SHUFRW: Regex = Regex::new(r"^shufrw (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");

    static ref R_SEQREAD: Regex = Regex::new(r"^seqread (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");
    static ref R_SEQWRITE: Regex =
        Regex::new(r"^seqwrite (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
            .expect("failed to create regex");
    static ref R_SEQRW: Regex = Regex::new(r"^seqrw (?P<name>[[:alnum:]]+) (?P<startpage>[x[[:xdigit:]]]+) (?P<count>[x[[:xdigit:]]]+)$")
        .expect("failed to create regex");

    static ref R_RANDINIT: Regex =
        Regex::new(r"^randinit (?P<name>[[:alnum:]]+)$").expect("failed to create regex");

    static ref R_READASSERT: Regex =
        Regex::new(r"^readassert (?P<onoff>on|off)$").expect("failed to create regex");
    static ref R_WRITEASSERT: Regex =
        Regex::new(r"^writeassert (?P<onoff>on|off)$").expect("failed to create regex");

    static ref R_CHECKFILE: Regex =
        Regex::new(r"^checkfile (?P<fdname>[[:alnum:]]+)$").expect("failed to create regex");
}

fn parse_hex_usize(s: &str) -> usize {
    let (s, mult) = if let Some(stripped) = s.strip_suffix("pg") {
        (stripped, 4096)
    } else {
        (s, 1)
    };
    mult * if let Some(stripped) = s.strip_prefix("0x") {
        usize::from_str_radix(stripped, 16).expect("invalid hex number")
    } else {
        usize::from_str(s).expect("invalid decimal number")
    }
}

fn parse_hex_u8(s: &str) -> u8 {
    u8::try_from(parse_hex_usize(s)).expect("u8 out of range")
}

pub fn parse(line: &str) -> Op {
    match line {
        "exit" => return Op::Exit,
        "checkhandler" => return Op::CheckHandler,
        "expectcrash" => return Op::ExpectCrash,
        "nomadvise" => return Op::NoMadvise,
        "checkswapfile" => return Op::CheckSwapfile,
        "randompageoffset" => return Op::RandomPageOffset,
        "requirecleanevictmadvise" => return Op::RequireCleanEvictMadvise,
        _ => (),
    };

    if let Some(read8) = R_READ8.captures(line) {
        return Op::Read8(Address {
            allocation: read8["name"].to_owned(),
            offset: parse_hex_usize(&read8["offset"]),
        });
    }

    if let Some(write8) = R_WRITE8.captures(line) {
        return Op::Write8(
            Address {
                allocation: write8["name"].to_owned(),
                offset: parse_hex_usize(&write8["offset"]),
            },
            parse_hex_usize(&write8["value"]) as u64,
        );
    }

    if let Some(read1) = R_READ1.captures(line) {
        return Op::Read1(Address {
            allocation: read1["name"].to_owned(),
            offset: parse_hex_usize(&read1["offset"]),
        });
    }

    if let Some(write1) = R_WRITE1.captures(line) {
        return Op::Write1(
            Address {
                allocation: write1["name"].to_owned(),
                offset: parse_hex_usize(&write1["offset"]),
            },
            parse_hex_u8(&write1["value"]),
        );
    }

    if let Some(alloc) = R_ALLOC.captures(line) {
        return Op::Alloc(alloc["name"].to_owned(), parse_hex_usize(&alloc["size"]));
    }

    if let Some(map) = R_MAP.captures(line) {
        return Op::Map(
            map["name"].to_owned(),
            map["fdname"].to_owned(),
            parse_hex_usize(&map["size"]),
        );
    }

    if let Some(free) = R_FREE.captures(line) {
        return Op::Free(free["name"].to_owned());
    }

    if let Some(lorm) = R_LORM.captures(line) {
        return Op::LORM(parse_hex_usize(&lorm["size"]));
    }

    if let Some(open) = R_MKFILE.captures(line) {
        return Op::MakeFile(open["fdname"].to_owned(), parse_hex_usize(&open["size"]));
    }

    if let Some(close) = R_CLOSE.captures(line) {
        return Op::Close(close["fdname"].to_owned());
    }

    if let Some(c) = R_CHECKFILE.captures(line) {
        return Op::CheckFile(c["fdname"].to_owned());
    }

    if let Some(c) = R_MAPPINGASSERT.captures(line) {
        return Op::MappingAssert(&c["onoff"] == "on");
    }

    if let Some(c) = R_READASSERT.captures(line) {
        return Op::ReadAssert(&c["onoff"] == "on");
    }

    if let Some(c) = R_WRITEASSERT.captures(line) {
        return Op::WriteAssert(&c["onoff"] == "on");
    }

    if let Some(c) = R_CHECKMAPPING.captures(line) {
        return Op::CheckMapping(c["name"].to_owned());
    }

    if let Some(c) = R_RANDREAD.captures(line) {
        return Op::RandRead(c["name"].to_owned(), parse_hex_usize(&c["count"]));
    }

    if let Some(c) = R_RANDWRITE.captures(line) {
        return Op::RandWrite(c["name"].to_owned(), parse_hex_usize(&c["count"]));
    }

    if let Some(c) = R_RANDRW.captures(line) {
        return Op::RandRW(c["name"].to_owned(), parse_hex_usize(&c["count"]));
    }

    if let Some(c) = R_SHUFREAD.captures(line) {
        return Op::ShufRead(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_SHUFWRITE.captures(line) {
        return Op::ShufWrite(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_SHUFRW.captures(line) {
        return Op::ShufRW(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_SEQREAD.captures(line) {
        return Op::SeqRead(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_SEQWRITE.captures(line) {
        return Op::SeqWrite(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_SEQRW.captures(line) {
        return Op::SeqRW(
            c["name"].to_owned(),
            parse_hex_usize(&c["startpage"]),
            parse_hex_usize(&c["count"]),
        );
    }

    if let Some(c) = R_RANDINIT.captures(line) {
        return Op::RandInit(c["name"].to_owned());
    }

    panic!("invalid input line {}", line);
}

#[cfg(test)]
mod test {
    use super::{parse, Address, Op};

    #[test]
    fn test_parse() {
        let input = r"
read8 a1 0x1234
read8 a1 0x100pg
write8 a2 5678 0x5678
read1 a1 0x1234
write1 a4 0x1234 0xff
alloc hello 0x123456
alloc hello 0x123pg
alloc hello 123pg
map a1 f2 0x12345
map a1 f2 0x12345pg
free a1245
lorm 21412
lorm 0x12345
mkfile f12345 12345
close f23232
exit
mappingassert off
mappingassert on
checkhandler
checkmapping a1
expectcrash
randread a2 100
randwrite a1 0x100
randrw a1 0x100
shufread a1 100 100
shufread a1 0x100 0x100
shufwrite a1 0x100 0x100
shufwrite a1 100 100
shufrw a1 0x100 0x100
shufrw a1 100 100
randinit a1
      "
        .trim();
        let ops = input
            .lines()
            .filter(|s| {
                let t = s.trim();
                !t.is_empty() && !t.starts_with("#")
            })
            .map(parse)
            .collect::<Vec<_>>();
        assert_eq!(
            ops,
            vec![
                Op::Read8(Address {
                    allocation: "a1".to_owned(),
                    offset: 4660
                }),
                Op::Read8(Address {
                    allocation: "a1".to_owned(),
                    offset: 1048576
                }),
                Op::Write8(
                    Address {
                        allocation: "a2".to_owned(),
                        offset: 5678
                    },
                    22136
                ),
                Op::Read1(Address {
                    allocation: "a1".to_owned(),
                    offset: 4660
                }),
                Op::Write1(
                    Address {
                        allocation: "a4".to_owned(),
                        offset: 4660
                    },
                    255
                ),
                Op::Alloc("hello".to_owned(), 1193046),
                Op::Alloc("hello".to_owned(), 1191936),
                Op::Alloc("hello".to_owned(), 503808),
                Op::Map("a1".to_owned(), "f2".to_owned(), 74565),
                Op::Map("a1".to_owned(), "f2".to_owned(), 305418240),
                Op::Free("a1245".to_owned()),
                Op::LORM(21412),
                Op::LORM(74565),
                Op::MakeFile("f12345".to_owned(), 12345),
                Op::Close("f23232".to_owned()),
                Op::Exit,
                Op::MappingAssert(false),
                Op::MappingAssert(true),
                Op::CheckHandler,
                Op::CheckMapping("a1".to_owned()),
                Op::ExpectCrash,
                Op::RandRead("a2".to_owned(), 100),
                Op::RandWrite("a1".to_owned(), 256),
                Op::RandRW("a1".to_owned(), 256),
                Op::ShufRead("a1".to_owned(), 100, 100),
                Op::ShufRead("a1".to_owned(), 256, 256),
                Op::ShufWrite("a1".to_owned(), 256, 256),
                Op::ShufWrite("a1".to_owned(), 100, 100),
                Op::ShufRW("a1".to_owned(), 256, 256),
                Op::ShufRW("a1".to_owned(), 100, 100),
                Op::RandInit("a1".to_owned())
            ]
        );
    }
}
