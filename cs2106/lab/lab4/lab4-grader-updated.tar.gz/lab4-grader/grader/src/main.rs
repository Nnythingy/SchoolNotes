#![allow(clippy::upper_case_acronyms)]

use std::collections::{HashMap, VecDeque};
use std::env;
use std::fs::{self, File};
use std::io::{prelude::*, stdin, SeekFrom};
use std::os::unix::net::UnixStream;
use std::os::unix::prelude::*;
use std::process::Command;
use std::process::Stdio;

use byteorder::{NativeEndian, ReadBytesExt, WriteBytesExt};
use command_fds::CommandFdExt;
use rand::prelude::SliceRandom;
use rand::{Rng, SeedableRng};
use step_range::StepRange;

use crate::ipc::SendIPC;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Address {
    allocation: AllocationIndex,
    offset: usize,
}

pub type AllocationIndex = String;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Allocation {
    base: usize,
    size: usize,
    file: Option<FileIndex>,
    freed: bool,
    shadow: Vec<u8>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FD {
    fd: i32,
    closed: bool,
}

#[derive(Debug)]
pub struct OpenFile {
    path: String,
    file: File,
    shadow: Vec<u8>,
}

pub type FileIndex = String;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Op {
    // <allocation> := (?P<name>[[:alnum:]]+) (?P<offset>[x[[:xdigit:]]]+)
    // read8 <allocation>
    Read8(Address),
    // write8 <allocation> (?P<value>[x[[:xdigit:]]]+)
    Write8(Address, u64),
    // read1 <allocation>
    Read1(Address),
    // write1 <allocation> (?P<value>[x[[:xdigit:]]]+)
    Write1(Address, u8),
    // alloc (?P<name>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+)
    Alloc(AllocationIndex, usize),
    // map (?P<name>[[:alnum:]]+) (?P<fdname>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+)
    Map(AllocationIndex, FileIndex, usize),
    // free (?P<name>[[:alnum:]]+)
    Free(AllocationIndex),
    // lorm (?P<size>[x[[:xdigit:]]]+)
    LORM(usize),
    // mkfile (?P<fdname>[[:alnum:]]+) (?P<size>[x[[:xdigit:]]]+(pg)?)
    MakeFile(FileIndex, usize),
    // close (?P<fdname>[[:alnum:]]+)
    Close(FileIndex),
    // exit
    Exit,
    // checkswapfile
    CheckSwapfile,
    // checkfile fdname
    CheckFile(FileIndex),
    // assert on/off
    MappingAssert(bool),
    // readassert on/off
    ReadAssert(bool),
    // writeassert on/off
    WriteAssert(bool),
    // checkmapping aname
    CheckMapping(AllocationIndex),
    // checkhandler
    CheckHandler,
    // expectcrash
    ExpectCrash,
    // nomadvise
    NoMadvise,
    // randread aname countmaybe
    RandRead(AllocationIndex, usize),
    // randwrite aname count
    RandWrite(AllocationIndex, usize),
    // randrw aname count
    RandRW(AllocationIndex, usize),
    // shufread aname startpageindex pagecount
    ShufRead(AllocationIndex, usize, usize),
    // shufwrite aname startpageindex pagecount
    ShufWrite(AllocationIndex, usize, usize),
    // shufrw aname startpageindex pagecount
    ShufRW(AllocationIndex, usize, usize),
    // seqread aname startpageindex pagecount
    SeqRead(AllocationIndex, usize, usize),
    // seqwrite aname startpageindex pagecount
    SeqWrite(AllocationIndex, usize, usize),
    // seqrw aname startpageindex pagecount
    SeqRW(AllocationIndex, usize, usize),
    // randinit aname
    RandInit(AllocationIndex),
    Open(FileIndex, String),
    RandomPageOffset,
    RequireCleanEvictMadvise,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Response {
    Val1(u8),
    Val8(u64),
    Address(usize),
    FD(FD),
    None,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PageState {
    Nonresident,
    Clean,
    Dirty,
}
use PageState::*;

fn pagestate_to_str(state: Option<PageState>) -> &'static str {
    match state {
        Some(Nonresident) => "none",
        Some(Clean) => "readonly",
        Some(Dirty) => "readwrite",
        None => "unmapped",
    }
}

fn procmap_to_str(state: Option<(bool, bool, bool)>) -> &'static str {
    match state {
        Some((false, false, _)) => "none",
        Some((true, false, _)) => "readonly",
        Some((true | false, true, _)) => "readwrite",
        None => "unmapped",
    }
}

pub struct State {
    mapping_assert: bool,
    expecting_crash: bool,
    no_madvise: bool,
    read_assert: bool,
    write_assert: bool,
    allocs: HashMap<String, Allocation>,
    child_fds: HashMap<String, FD>,
    files: HashMap<String, OpenFile>,
    errors: Vec<String>,
    pt: Box<pt::AddressSpace<PageState>>,
    fifo: VecDeque<Address>,
    lorm_pages: usize,
    write_expected: bool,
    pid: u32,
    random_page_offsets: bool,
    require_clean_evict_madvise: bool,
}

macro_rules! state_check_allocation {
    ($errors:expr, $aname: expr, $alloc:expr, $expected:expr, $actual:expr, $checkfn:ident) => {
        if let Some(err) = $checkfn($alloc, $expected, $actual) {
            let expstr = pagestate_to_str($expected.get(err));
            let actstr = procmap_to_str($actual.get(err));
            $errors.push(format!(
                "at addr {:x} in alloc {}, expected page permissions {} but got {}",
                err - $alloc.base,
                $aname,
                expstr,
                actstr
            ));
        }
    };
}

impl State {
    fn new(pid: u32) -> Self {
        State {
            mapping_assert: true,
            expecting_crash: false,
            no_madvise: false,
            read_assert: true,
            write_assert: false,
            allocs: HashMap::new(),
            child_fds: HashMap::new(),
            files: HashMap::new(),
            errors: vec![],
            pt: Box::new(pt::AddressSpace::new()),
            fifo: VecDeque::new(),
            lorm_pages: 2106,
            pid,
            write_expected: false,
            random_page_offsets: false,
            require_clean_evict_madvise: false,
        }
    }

    fn linear_address(&self, addr: &Address) -> usize {
        self.allocs[&addr.allocation].base + addr.offset
    }

    fn flush_page(&mut self, page: &Address) {
        if let Some(ref fdname) = self.allocs[&page.allocation].file {
            self.write_expected = true;
            let range = page.offset..page.offset + 4096;
            self.files.get_mut(fdname).unwrap().shadow[range.clone()]
                .copy_from_slice(&self.allocs[&page.allocation].shadow[range]);
        }
    }

    fn make_space(&mut self, num_pages: usize) {
        while !self.fifo.is_empty() && self.fifo.len() + num_pages > self.lorm_pages {
            let evicted = self.fifo.pop_front().unwrap();
            let old_state = self
                .pt
                .set(self.linear_address(&evicted), Some(Nonresident));
            if old_state == Some(PageState::Dirty) {
                self.flush_page(&evicted);
                self.write_expected = true;
            }
            if !self.no_madvise
                && (old_state == Some(PageState::Dirty) || self.require_clean_evict_madvise)
                && proc::pagemap_present(
                    self.pid,
                    self.allocs[&evicted.allocation].base + evicted.offset,
                )
            {
                self.errors.push(
                    format!("kernel page at addr {:x} in alloc {} not freed after page evicted; missing MADV_DONTNEED?", evicted.offset, evicted.allocation));
            }
        }
    }

    fn do_read(&mut self, addr: &Address) {
        let la = self.linear_address(addr);
        match self.pt.get(la) {
            Some(Nonresident) => (),
            None if !self.expecting_crash => panic!("TC reading unmapped page"),
            None | Some(Clean) | Some(Dirty) => return,
        }
        self.make_space(1);
        self.pt.set(la, Some(Clean));
        self.fifo.push_back(Address {
            allocation: addr.allocation.clone(),
            offset: addr.offset & !0xFFF,
        });
    }

    fn do_write(&mut self, addr: &Address) {
        let la = self.linear_address(addr);
        let state = self.pt.get(la);
        match state {
            Some(Clean) => (),
            Some(Nonresident) => {
                self.make_space(1);
                self.fifo.push_back(Address {
                    allocation: addr.allocation.clone(),
                    offset: addr.offset & !0xFFF,
                });
            }
            None if !self.expecting_crash => panic!("TC writing unmapped page"),
            None | Some(Dirty) => return,
        }
        self.pt.set(la, Some(Dirty));
    }

    fn alloc(&mut self, name: String, base: usize, size: usize, file: Option<String>) {
        let size = round_page(size);
        self.allocs.insert(
            name,
            Allocation {
                base,
                size,
                file,
                freed: false,
                shadow: vec![0u8; size],
            },
        );
        self.pt.set_range(base, size, Some(Nonresident));
    }

    fn free(&mut self, name: &str) {
        let oldfifo = std::mem::take(&mut self.fifo);
        for addr in oldfifo.into_iter() {
            if addr.allocation == name {
                if self.pt.get(self.linear_address(&addr)) == Some(PageState::Dirty) {
                    self.flush_page(&addr);
                }
            } else {
                self.fifo.push_back(addr);
            }
        }

        let alloc = self
            .allocs
            .get_mut(name)
            .expect("freeing unknown allocation");
        if alloc.freed {
            panic!("freeing freed allocation {}", name);
        }
        alloc.freed = true;
        let alloc = &*alloc;
        self.pt.set_range(alloc.base, alloc.size, None);
    }

    fn check_handler(&mut self) {
        if !proc::check_sigsegv_handler(self.pid) {
            self.errors.push("missing SIGSEGV handler".to_owned());
        }
    }

    fn check_swapfile(&mut self) {
        let total_size = self
            .allocs
            .values()
            .filter(|a| a.file.is_none())
            .map(|a| a.size)
            .sum::<usize>() as u64;
        if let Ok(m) = std::fs::metadata(format!("/proc/{}/cwd/{}.swap", self.pid, self.pid)) {
            if m.size() > total_size {
                self.errors.push(format!(
                    "swapfile too large: {} bytes > {} bytes",
                    m.size(),
                    total_size,
                ));
            }
        } else {
            self.errors.push("failed to find swapfile".to_owned());
        }
    }

    #[allow(dead_code)]
    fn check_allocation(&mut self, aname: &str) {
        let actual = proc::maps(self.pid);
        let allocation = &self.allocs[aname];
        state_check_allocation!(
            self.errors,
            aname,
            allocation,
            &self.pt,
            &actual,
            check_allocation
        );
    }

    fn check_allocation_presence(&mut self, aname: &str) {
        let actual = proc::maps(self.pid);
        let allocation = &self.allocs[aname];
        state_check_allocation!(
            self.errors,
            aname,
            allocation,
            &self.pt,
            &actual,
            check_allocation_presence
        );
    }

    fn check_allocations(&mut self) {
        let actual = proc::maps(self.pid);
        for (aname, allocation) in self.allocs.iter() {
            state_check_allocation!(
                self.errors,
                aname,
                allocation,
                &self.pt,
                &actual,
                check_allocation
            );
        }
    }

    fn find_overlap(&self, base: usize, size: usize) -> Option<(usize, usize)> {
        for alloc in self.allocs.values() {
            let disjoint = base >= alloc.base + alloc.size || alloc.base >= base + size;
            if !disjoint {
                return Some((alloc.base, alloc.size));
            }
        }
        None
    }

    fn check_file(&mut self, fdname: &str) {
        let file = self.files.get_mut(fdname).unwrap();
        let filesize = file.file.seek(SeekFrom::End(0)).unwrap() as usize;
        if filesize != file.shadow.len() {
            self.errors.push(format!(
                "file {} has wrong size: expected {}, got {}",
                file.path,
                file.shadow.len(),
                filesize
            ));
        }
        file.file.seek(SeekFrom::Start(0)).unwrap();
        let mut buf: Vec<u8> = Vec::with_capacity(filesize);
        file.file.read_to_end(&mut buf).unwrap();
        if buf != file.shadow {
            self.errors
                .push(format!("file {} has wrong contents", file.path));
        }
    }

    fn send_op(&mut self, ipc_socket: &mut UnixStream, op: &Op) -> Result<(), ()> {
        self.write_expected = false;
        let write_seen = match ipc_socket.send(op, self) {
            Ok((ref response, write_seen)) => {
                match (&op, response) {
                    (Op::Read8(addr), Response::Val8(actual)) => {
                        let alloc = &self.allocs[&addr.allocation];
                        if addr.offset + 8 <= alloc.size {
                            if self.read_assert {
                                let expected = (&alloc.shadow[addr.offset..addr.offset + 8])
                                    .read_u64::<NativeEndian>()
                                    .unwrap();
                                if expected != *actual {
                                    self.errors.push(format!(
                                        "expected {} when reading u64 {}+{}, got {}",
                                        expected, addr.allocation, addr.offset, actual,
                                    ));
                                }
                            }
                            self.do_read(addr);
                        }
                    }
                    (Op::Read1(addr), Response::Val1(actual)) => {
                        let alloc = &self.allocs[&addr.allocation];
                        if addr.offset < alloc.size {
                            if self.read_assert {
                                let expected = alloc.shadow[addr.offset];
                                if expected != *actual {
                                    self.errors.push(format!(
                                        "expected {} when reading u8 {}+{}, got {}",
                                        expected, addr.allocation, addr.offset, actual,
                                    ));
                                }
                            }
                            self.do_read(addr);
                        }
                    }
                    (Op::Alloc(aname, size), Response::Address(addr)) => {
                        if *addr == 0 || *addr == !0 {
                            self.errors.push(format!(
                                "userswap_alloc({}) returned null or MAP_FAILED",
                                size
                            ));
                            return Err(());
                        }
                        if *addr & 0xFFF != 0 {
                            self.errors.push(format!(
                                "userswap_alloc({}) returned non page-aligned address {:x}, unusable",
                                size, addr
                            ));
                            return Err(());
                        }
                        if let Some((base2, size2)) = self.find_overlap(*addr, *size) {
                            self.errors.push(format!(
                                "userswap_alloc({}) returned address {:x} which overlaps with existing allocation {:x} size {}",
                                size, addr, base2, size2
                            ));
                            return Err(());
                        }
                        self.alloc(aname.clone(), *addr, *size, None);
                    }
                    (Op::Map(aname, fdname, size), Response::Address(addr)) => {
                        if *addr == 0 || *addr == !0 {
                            self.errors.push(format!(
                                "userswap_map(<fd>, {}) returned null or MAP_FAILED",
                                size
                            ));
                            return Err(());
                        }
                        if *addr & 0xFFF != 0 {
                            self.errors.push(format!(
                                "userswap_map(<fd>, {}) returned non page-aligned address {:x}, unusable",
                                size, addr
                            ));
                            return Err(());
                        }
                        if let Some((base2, size2)) = self.find_overlap(*addr, *size) {
                            self.errors.push(format!(
                                "userswap_map(<fd>, {}) returned address {:x} which overlaps with existing allocation {:x} size {}",
                                size, addr, base2, size2
                            ));
                            return Err(());
                        }
                        let size = round_page(*size);
                        self.alloc(aname.clone(), *addr, size, Some(fdname.clone()));
                        if size > self.files[fdname].shadow.len() {
                            self.files.get_mut(fdname).unwrap().shadow.resize(size, 0);
                        }
                    }
                    (Op::Open(fdname, path), Response::FD(fd)) => {
                        if fd.fd < 0 {
                            panic!("failed to open file {}", path);
                        }
                        self.child_fds.insert(fdname.clone(), *fd);
                    }

                    (Op::Write8(addr, value), Response::None) => {
                        let alloc = self.allocs.get_mut(&addr.allocation).unwrap();
                        if addr.offset + 8 <= alloc.size {
                            (&mut alloc.shadow[addr.offset..addr.offset + 8])
                                .write_u64::<NativeEndian>(*value)
                                .unwrap();
                            self.do_write(addr);
                        }
                    }
                    (Op::Write1(addr, value), Response::None) => {
                        let alloc = self.allocs.get_mut(&addr.allocation).unwrap();
                        if addr.offset < alloc.size {
                            alloc.shadow[addr.offset] = *value;
                            self.do_write(addr);
                        }
                    }
                    (Op::Free(aname), Response::None) => {
                        self.free(aname);
                    }
                    (Op::LORM(size), Response::None) => {
                        self.lorm_pages = (size >> 12) + (if size & 0xFFF == 0 { 0 } else { 1 });
                        self.make_space(0);
                    }
                    (Op::Close(fdname), Response::None) => {
                        self.child_fds.get_mut(fdname).unwrap().closed = true;
                    }
                    (Op::Exit, Response::None) | (Op::WriteAssert(_), Response::None) => {}
                    _ => panic!("invalid response {:?} for op {:?}", response, op),
                }
                write_seen
            }
            Err(err) => {
                if !self.expecting_crash {
                    eprintln!("error communicating with runner: {:?}", err);
                }
                return Err(());
            }
        };

        if self.write_assert && write_seen && !self.write_expected {
            self.write_assert = false;
            self.errors.push("unexpected write(s) seen".to_owned());
        }
        if self.mapping_assert {
            self.check_allocations();
        }
        Ok(())
    }
}

fn check_allocation(
    alloc: &Allocation,
    expected: &pt::AddressSpace<PageState>,
    actual: &pt::AddressSpace<(bool, bool, bool)>,
) -> Option<usize> {
    pt::compare_range(alloc.base, alloc.size, expected, actual, |e, a| {
        matches!(
            (e, a),
            (PageState::Nonresident, (false, false, _))
                | (PageState::Clean, (true, false, _))
                | (PageState::Dirty, (true | false, true, _))
        )
    })
}

fn check_allocation_presence(
    alloc: &Allocation,
    expected: &pt::AddressSpace<PageState>,
    actual: &pt::AddressSpace<(bool, bool, bool)>,
) -> Option<usize> {
    pt::compare_range(alloc.base, alloc.size, expected, actual, |_, _| true)
}

fn main() {
    let (mut ipc_socket, child_socket) = UnixStream::pair().expect("failed to create socketpair");
    let child_socket_fd = child_socket.as_raw_fd();

    let mut runner = Command::new(env::args_os().nth(1).unwrap())
        .stdin(Stdio::null())
        .stdout(if std::env::var("US_RUNNER_DEBUG").is_ok() {
            Stdio::inherit()
        } else {
            Stdio::null()
        })
        .stderr(if std::env::var("US_RUNNER_DEBUG").is_ok() {
            Stdio::inherit()
        } else {
            Stdio::null()
        })
        .args(
            env::args_os()
                .skip(2)
                .chain(std::iter::once(child_socket_fd.to_string().into())),
        )
        .preserved_fds(vec![child_socket_fd])
        .spawn()
        .expect("failed to spawn runner");
    drop(child_socket);

    let mut send_err = false;
    let mut rng = rand::rngs::StdRng::from_seed(b"CS2106 2110 lab 4 p9we4867rgdfss".to_owned());
    let rand_dist = rand::distributions::Uniform::new(0u32, 16);
    let mut state = State::new(runner.id());

    macro_rules! page_offset {
        ($page:expr) => {
            $page
                + if state.random_page_offsets {
                    (($page >> 9) & 0xFF8)
                } else {
                    0
                }
        };
    }

    'outer: for op in stdin().lock().lines().filter_map(|r| {
        let line = r.expect("failed to read from stdin");
        if line.trim().starts_with('#') || line.trim().is_empty() {
            None
        } else {
            Some(parse(&line))
        }
    }) {
        match &op {
            Op::MappingAssert(onoff) => state.mapping_assert = *onoff,
            Op::ReadAssert(onoff) => state.read_assert = *onoff,
            Op::RandomPageOffset => state.random_page_offsets = true,
            Op::WriteAssert(onoff) => {
                state.write_assert = *onoff;
            }
            Op::CheckMapping(aname) => state.check_allocation_presence(aname),
            Op::CheckHandler => state.check_handler(),
            Op::CheckFile(fdname) => state.check_file(fdname),
            Op::ExpectCrash => state.expecting_crash = true,
            Op::NoMadvise => state.no_madvise = true,
            Op::RequireCleanEvictMadvise => state.require_clean_evict_madvise = true,
            Op::CheckSwapfile => state.check_swapfile(), // todo
            Op::MakeFile(fdname, size) => {
                let openfile = util::mkrandfile(state.pid, *size);
                if state
                    .send_op(
                        &mut ipc_socket,
                        &Op::Open(fdname.clone(), openfile.path.clone()),
                    )
                    .is_err()
                {
                    send_err = true;
                    break 'outer;
                }
                fs::remove_file(&openfile.path).unwrap();
                state.files.insert(fdname.clone(), openfile);
            }
            Op::RandRead(aname, count) => {
                let size = state.allocs[aname].size;
                for _i in 0..*count {
                    let op = if rng.sample(rand_dist) < 12 {
                        // 75% read8
                        Op::Read8(Address {
                            allocation: aname.clone(),
                            offset: rng.gen_range(0..size) & !7,
                        })
                    } else {
                        Op::Read1(Address {
                            allocation: aname.clone(),
                            offset: rng.gen_range(0..size),
                        })
                    };
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::RandWrite(aname, count) => {
                let size = state.allocs[aname].size;
                for _i in 0..*count {
                    let op = if rng.sample(rand_dist) < 12 {
                        // 75% write8
                        Op::Write8(
                            Address {
                                allocation: aname.clone(),
                                offset: rng.gen_range(0..size) & !7,
                            },
                            rng.gen(),
                        )
                    } else {
                        Op::Write1(
                            Address {
                                allocation: aname.clone(),
                                offset: rng.gen_range(0..size),
                            },
                            rng.gen(),
                        )
                    };
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::RandRW(aname, count) => {
                let size = state.allocs[aname].size;
                for _i in 0..*count {
                    let op = match rng.sample(rand_dist) {
                        0 | 1 | 2 | 3 | 4 | 5 => Op::Read8(Address {
                            allocation: aname.clone(),
                            offset: rng.gen_range(0..size) & !7,
                        }),
                        6 | 7 | 8 | 9 | 10 | 11 => Op::Write8(
                            Address {
                                allocation: aname.clone(),
                                offset: rng.gen_range(0..size) & !7,
                            },
                            rng.gen(),
                        ),
                        12 | 13 => Op::Read1(Address {
                            allocation: aname.clone(),
                            offset: rng.gen_range(0..size),
                        }),
                        14 | 15 => Op::Write1(
                            Address {
                                allocation: aname.clone(),
                                offset: rng.gen_range(0..size),
                            },
                            rng.gen(),
                        ),
                        _ => panic!(),
                    };
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::ShufRead(aname, startpage, count) | Op::SeqRead(aname, startpage, count) => {
                if (startpage + count) << 12 > state.allocs[aname].size {
                    panic!(
                        "seq/shufread {} {} {} out of bounds for alloc of size {}",
                        aname, startpage, count, state.allocs[aname].size
                    );
                }
                let mut pages = (*startpage..startpage + count)
                    .map(|p| p << 12)
                    .collect::<Vec<_>>();
                if let Op::ShufRead(..) = op {
                    pages.shuffle(&mut rng);
                }
                for page in pages {
                    let op = Op::Read8(Address {
                        allocation: aname.clone(),
                        offset: page_offset!(page),
                    });
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::ShufWrite(aname, startpage, count) | Op::SeqWrite(aname, startpage, count) => {
                if (startpage + count) << 12 > state.allocs[aname].size {
                    panic!(
                        "seq/shufwrite {} {} {} out of bounds for alloc of size {}",
                        aname, startpage, count, state.allocs[aname].size
                    );
                }
                let mut pages = (*startpage..startpage + count)
                    .map(|p| p << 12)
                    .collect::<Vec<_>>();
                if let Op::ShufWrite(..) = op {
                    pages.shuffle(&mut rng);
                }
                for page in pages {
                    let op = Op::Write8(
                        Address {
                            allocation: aname.clone(),
                            offset: page_offset!(page),
                        },
                        rng.gen(),
                    );
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::ShufRW(aname, startpage, count) | Op::SeqRW(aname, startpage, count) => {
                if (startpage + count) << 12 > state.allocs[aname].size {
                    panic!(
                        "seq/shufrw {} {} {} out of bounds for alloc of size {}",
                        aname, startpage, count, state.allocs[aname].size
                    );
                }
                let mut pages = (*startpage..startpage + count)
                    .map(|p| p << 12)
                    .collect::<Vec<_>>();
                if let Op::ShufRW(..) = op {
                    pages.shuffle(&mut rng);
                }
                for page in pages {
                    let op = if rng.sample(&rand_dist) < 8 {
                        Op::Read8(Address {
                            allocation: aname.clone(),
                            offset: page_offset!(page),
                        })
                    } else {
                        Op::Write8(
                            Address {
                                allocation: aname.clone(),
                                offset: page_offset!(page),
                            },
                            rng.gen(),
                        )
                    };
                    if state.send_op(&mut ipc_socket, &op).is_err() {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::RandInit(aname) => {
                let size = state.allocs[aname].size;
                for addr in StepRange(0, size, 8) {
                    if state
                        .send_op(
                            &mut ipc_socket,
                            &Op::Write8(
                                Address {
                                    allocation: aname.clone(),
                                    offset: addr,
                                },
                                rng.gen(),
                            ),
                        )
                        .is_err()
                    {
                        send_err = true;
                        break 'outer;
                    }
                }
            }
            Op::Exit => break,
            _ => {
                if state.send_op(&mut ipc_socket, &op).is_err() {
                    send_err = true;
                    break;
                }
            }
        }
    }

    for attempt in 0..2 {
        if let Some(exit) = runner.try_wait().expect("failed to wait on runner") {
            if let Some(signal) = exit.signal() {
                if !state.expecting_crash {
                    eprintln!(
                        "runner exited with signal {} ({})",
                        strsigabbrev(signal),
                        strsig(signal)
                    );
                    state.errors.push(format!(
                        "exited with signal {} ({})",
                        strsigabbrev(signal),
                        strsig(signal)
                    ));
                }
            } else if state.expecting_crash {
                state
                    .errors
                    .push("expected crash but testee did not crash".to_owned());
            } else if send_err {
                if let Some(code) = exit.code() {
                    state
                        .errors
                        .push(format!("testee exited prematurely with exit code {}", code));
                } else {
                    state.errors.push("testee exited prematurely".to_owned());
                }
            }
            break;
        } else {
            if state.expecting_crash {
                if attempt < 1 {
                    // give it 5 seconds to die
                    std::thread::sleep(std::time::Duration::from_secs(5));
                    continue;
                }
                state
                    .errors
                    .push("expected crash but testee did not crash".to_owned());
            } else if send_err {
                state
                    .errors
                    .push("testee stopped receiving commands".to_owned());
            }
            runner.kill().expect("failed to kill runner");
            runner.wait().expect("failed to wait on runner");
            break;
        }
    }

    for error in state.errors.iter() {
        println!("error: {}", error);
    }
    std::process::exit(if state.errors.is_empty() { 0 } else { 1 });
}

mod input;
mod ipc;
mod proc;
mod pt;
mod step_range;
mod util;

use input::parse;
use util::{round_page, strsig, strsigabbrev};
