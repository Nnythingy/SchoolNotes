use std::fmt::Debug;

use crate::step_range::StepRange;

fn break_address(addr: usize) -> (usize, usize, usize, usize, usize) {
    (
        (addr >> 39) & 0x1FF,
        (addr >> 30) & 0x1FF,
        (addr >> 21) & 0x1FF,
        (addr >> 12) & 0x1FF,
        addr & 0xFFF,
    )
}

pub fn compare_range<
    T: Debug + Clone + Copy + PartialEq + Eq,
    U: Debug + Clone + Copy + PartialEq + Eq,
    F,
>(
    start: usize,
    size: usize,
    left: &AddressSpace<T>,
    right: &AddressSpace<U>,
    mut comparer: F,
) -> Option<usize>
where
    F: FnMut(T, U) -> bool,
{
    if start & 0xFFF != 0 {
        panic!("non page-aligned address in PT compare_range");
    }
    for addr in StepRange(start, start + size, 4096) {
        let leftent = left.get(addr);
        let rightent = right.get(addr);
        match (leftent, rightent) {
            (Some(leftent), Some(rightent)) if !comparer(leftent, rightent) => return Some(addr),
            (Some(_), Some(_)) | (None, None) => (),
            _ => return Some(addr),
        }
    }
    None
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AddressSpace<T: Debug + Clone + Copy + PartialEq + Eq> {
    pt: P4D<T>,
}

impl<T: Debug + Clone + Copy + PartialEq + Eq> AddressSpace<T> {
    pub fn new() -> Self {
        AddressSpace { pt: PT::new() }
    }

    pub fn get(&self, addr: usize) -> Option<T> {
        let (p4di, pudi, pmdi, pti, _) = break_address(addr);
        self.pt.0[p4di]
            .as_ref()
            .and_then(|pud| pud.0[pudi].as_ref())
            .and_then(|pmd| pmd.0[pmdi].as_ref())
            .and_then(|pt| pt.0[pti])
    }

    pub fn set(&mut self, addr: usize, state: Option<T>) -> Option<T> {
        let (p4di, pudi, pmdi, pti, _) = break_address(addr);

        std::mem::replace(
            &mut self.pt.0[p4di].get_or_insert_with(|| Box::new(PT::new())).0[pudi]
                .get_or_insert_with(|| Box::new(PT::new()))
                .0[pmdi]
                .get_or_insert_with(|| Box::new(PT::new()))
                .0[pti],
            state,
        )
    }

    pub fn set_range(&mut self, start: usize, size: usize, state: Option<T>) {
        if start & 0xFFF != 0 {
            panic!("non page-aligned address in PT set_range");
        }
        for addr in StepRange(start, start + size, 4096) {
            self.set(addr, state);
        }
    }

    #[allow(dead_code)]
    pub fn cmpxchg(&mut self, addr: usize, cmp: Option<T>, state: Option<T>) {
        let (p4di, pudi, pmdi, pti, _) = break_address(addr);
        let ent = &mut self.pt.0[p4di].get_or_insert_with(|| Box::new(PT::new())).0[pudi]
            .get_or_insert_with(|| Box::new(PT::new()))
            .0[pmdi]
            .get_or_insert_with(|| Box::new(PT::new()))
            .0[pti];
        if *ent == cmp {
            *ent = state;
        }
    }
}

type P4D<T> = PT<Box<PUD<T>>>;
type PUD<T> = PT<Box<PMD<T>>>;
type PMD<T> = PT<Box<PT<T>>>;

#[derive(Clone, Debug, Eq, PartialEq)]
struct PT<T: Debug + Clone + PartialEq + Eq>([Option<T>; 512]);

impl<T: Debug + Clone + PartialEq + Eq> PT<T> {
    fn new() -> Self {
        // array initialisation of non-copy is a bit tricky in rust :-(
        PT([
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None,
        ])
    }
}
