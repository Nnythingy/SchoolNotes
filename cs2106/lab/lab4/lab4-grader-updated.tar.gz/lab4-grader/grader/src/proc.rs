use std::{
    fs::File,
    io::{Read, Seek, SeekFrom},
};

use procfs::process::Process;

use crate::pt::AddressSpace;

pub fn maps(pid: u32) -> AddressSpace<(bool, bool, bool)> {
    let mut r = AddressSpace::new();
    let maps = Process::new(pid as i32).unwrap().maps().unwrap();
    for line in maps.iter() {
        let size = line.address.1 - line.address.0;
        if size > (128 << 20) {
            continue;
        }
        let perms = line.perms.as_bytes();
        let state = (perms[0] == b'r', perms[1] == b'w', perms[2] == b'x');
        r.set_range(
            line.address.0 as usize,
            (line.address.1 - line.address.0) as usize,
            Some(state),
        );
    }
    r
}

pub fn check_sigsegv_handler(pid: u32) -> bool {
    let sigcgt = Process::new(pid as i32).unwrap().status().unwrap().sigcgt;
    sigcgt & (1 << (11 - 1)) != 0
}

pub fn pagemap_present(pid: u32, address: usize) -> bool {
    let mut pagemap = File::open(format!("/proc/{}/pagemap", pid)).unwrap();
    pagemap
        .seek(SeekFrom::Start(((address >> 12) << 3) as u64))
        .unwrap();
    let mut buf = [0u8; 8];
    pagemap.read_exact(&mut buf).unwrap();
    let val = u64::from_le_bytes(buf);
    val & (1 << 63) != 0
}
