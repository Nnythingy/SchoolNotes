use std::io::prelude::*;
use std::mem::{size_of, transmute};
use std::os::unix::net::UnixStream;

use crate::{Op, Response, FD};

#[repr(u32)]
enum InputOp {
    Read8,
    Write8,
    Read1,
    Write1,
    Alloc,
    Map,
    Free,
    LORM,
    Open,
    Close,
    Exit,
}

#[repr(C)]
struct Input {
    addr: usize,
    argument: u64,
    fd: i32,
    op: InputOp,
}

fn make_input(op: &Op, state: &crate::State) -> [u8; size_of::<Input>()] {
    let i = match *op {
        Op::Read8(ref addr) => Input {
            addr: state.allocs[&addr.allocation].base + addr.offset,
            argument: 0,
            fd: 0,
            op: InputOp::Read8,
        },
        Op::Write8(ref addr, val) => Input {
            addr: state.allocs[&addr.allocation].base + addr.offset,
            argument: val,
            fd: 0,
            op: InputOp::Write8,
        },
        Op::Read1(ref addr) => Input {
            addr: state.allocs[&addr.allocation].base + addr.offset,
            argument: 0,
            fd: 0,
            op: InputOp::Read1,
        },
        Op::Write1(ref addr, val) => Input {
            addr: state.allocs[&addr.allocation].base + addr.offset,
            argument: val as u64,
            fd: 0,
            op: InputOp::Write1,
        },
        Op::Alloc(_, size) => Input {
            addr: 0,
            argument: size as u64,
            fd: 0,
            op: InputOp::Alloc,
        },
        Op::Map(_, ref file, size) => Input {
            addr: 0,
            argument: size as u64,
            fd: state.child_fds[file].fd,
            op: InputOp::Map,
        },
        Op::Free(ref allocation) => Input {
            addr: state.allocs[allocation].base,
            argument: 0,
            fd: 0,
            op: InputOp::Free,
        },
        Op::LORM(size) => Input {
            addr: 0,
            argument: size as u64,
            fd: 0,
            op: InputOp::LORM,
        },
        Op::Open(_, ref path) => Input {
            addr: 0,
            argument: 0,
            fd: path.as_bytes().len() as i32,
            op: InputOp::Open,
        },
        Op::Close(ref file) => Input {
            addr: 0,
            argument: 0,
            fd: state.child_fds[file].fd,
            op: InputOp::Close,
        },
        Op::Exit => Input {
            addr: 0,
            argument: 0,
            fd: 0,
            op: InputOp::Exit,
        },
        _ => panic!("invalid op for runner {:?}", op),
    };
    unsafe { transmute(i) }
}

pub trait SendIPC {
    fn send(&mut self, op: &Op, state: &crate::State) -> Result<(Response, bool), std::io::Error>;
}

impl SendIPC for UnixStream {
    fn send(&mut self, op: &Op, state: &crate::State) -> Result<(Response, bool), std::io::Error> {
        self.write_all(&make_input(op, state))?;
        if let Op::Open(_, ref path) = op {
            self.write_all(path.as_bytes())?;
        }

        Ok(if *op != Op::Exit {
            let mut response: [u8; 16] = [0; 16];
            self.read_exact(&mut response)?;
            (
                match *op {
                    Op::Read8(..) => {
                        Response::Val8(u64::from_le_bytes(response[..8].try_into().unwrap()))
                    }
                    Op::Read1(..) => Response::Val1(response[0]),
                    Op::Alloc(..) | Op::Map(..) => {
                        Response::Address(usize::from_le_bytes(response[..8].try_into().unwrap()))
                    }
                    Op::Open(..) => Response::FD(FD {
                        fd: i32::from_le_bytes(response[..4].try_into().unwrap()),
                        closed: false,
                    }),
                    _ => Response::None,
                },
                response[8] != 0,
            )
        } else {
            (Response::None, false)
        })
    }
}
