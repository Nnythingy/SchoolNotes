#include "userswap.h"

#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <unistd.h>

#define OPRINT(...) fprintf(private_stdout, __VA_ARGS__)
#define EPRINT(...) fprintf(private_stderr, __VA_ARGS__)

#define DPRINT(...)                                                                                \
  do {                                                                                             \
    if (!debug_print)                                                                              \
      break;                                                                                       \
    EPRINT(__VA_ARGS__);                                                                           \
  } while (0)

#define ALLOC_PAGES 2048ul
#define PAGE_INDEX_MASK (ALLOC_PAGES - 1ul)
#define PAGE_SIZE 4096ul
#define PAGE_SHIFT 12

static FILE *private_stdout;
static FILE *private_stderr;
static _Bool debug_print;
static char *shared_alloc;
static char *shared_map;
static pthread_barrier_t barrier;

static uint64_t lcg_next(uint64_t state) { return state * 0xaf251af3b0f025b5ull + 1; }

static void check_resident_pages(void) {
  size_t *pagemap = malloc(ALLOC_PAGES * 2 * 8);
  int f = open("/proc/self/pagemap", O_RDONLY);
  if (!f) {
    EPRINT("******* failed to open pagemap\n");
    _exit(2);
  }
  if (pread(f, pagemap, ALLOC_PAGES * 8, (size_t)shared_alloc >> 9) == -1 ||
      pread(f, pagemap + ALLOC_PAGES, ALLOC_PAGES * 8, (size_t)shared_map >> 9) == -1) {
    EPRINT("******* failed to read pagemap\n");
    _exit(2);
  }
  close(f);
  size_t resident = 0;
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    if (pagemap[i] & (1ul << 63)) {
      ++resident;
    }
  }
  free(pagemap);
  if (resident > 2106) {
    EPRINT("saw %zu resident pages (greater than LORM)\n", resident);
    _exit(1);
  }
}

static void act(size_t write, size_t *p, const size_t xor, intptr_t order) {
  const size_t val = (size_t)p ^ xor;
  if (write) {
    *p = val;
  } else {
    const size_t read = *p;
    if (read != val) {
      EPRINT("wrong value seen by thread %ld at %p: expected %lx, saw %lx\n", order, p, val, read);
      _exit(1);
    }
  }
}

#define END_STAGE(x)                                                                               \
  do {                                                                                             \
    if (order) {                                                                                   \
      OPRINT(x);                                                                                   \
    }                                                                                              \
    pthread_barrier_wait(&barrier);                                                                \
    if (!order) {                                                                                  \
      check_resident_pages();                                                                      \
      OPRINT(x);                                                                                   \
    }                                                                                              \
    pthread_barrier_wait(&barrier);                                                                \
  } while (0)

static void *do_test(void *orderp) {
  intptr_t order = (intptr_t)orderp;
  const size_t xor = (size_t)order * 7887151440719953349ul;
  const size_t page_offset = (1 + order) * sizeof(size_t);

  // part 1: read all pages sequentially
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    size_t *alloc = (size_t *)(((i & 1) ? shared_map : shared_alloc) +
                               PAGE_SIZE * ((i >> 1) & PAGE_INDEX_MASK) + page_offset);
    size_t read = *alloc;
    if (read != 0) {
      EPRINT("wrong value seen by thread %ld at %p: expected 0, saw %lx\n", order, alloc, read);
      _exit(1);
    }
  }
  END_STAGE("1");

  uint64_t lcg_state = xor^1826251826398782605ul;

  // part 2: read pages randomly
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    size_t *alloc = (size_t *)(((lcg_state & 1) ? shared_map : shared_alloc) +
                               (((lcg_state >> 1) & PAGE_INDEX_MASK) << PAGE_SHIFT) + page_offset);
    size_t read = *alloc;
    if (read != 0) {
      EPRINT("wrong value seen by thread %ld at %p: expected 0, saw %lx\n", order, alloc, read);
      _exit(1);
    }
    lcg_state = lcg_next(lcg_state);
  }
  END_STAGE("2");

  // part 3: write to all pages
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    size_t *alloc = (size_t *)(((i & 1) ? shared_map : shared_alloc) +
                               PAGE_SIZE * ((i >> 1) & PAGE_INDEX_MASK) + page_offset);
    act(1, alloc, xor, order);
  }
  END_STAGE("3");

  // part 4: read pages sequentially
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    size_t *alloc = (size_t *)(((i & 1) ? shared_map : shared_alloc) +
                               PAGE_SIZE * ((i >> 1) & PAGE_INDEX_MASK) + page_offset);
    act(0, alloc, xor, order);
  }
  END_STAGE("4");

  // part 5: read pages randomly
  for (size_t i = 0; i < ALLOC_PAGES * 2; ++i) {
    size_t *alloc = (size_t *)(((lcg_state & 1) ? shared_map : shared_alloc) +
                               (((lcg_state >> 1) & PAGE_INDEX_MASK) << PAGE_SHIFT) + page_offset);
    act(0, alloc, xor, order);
    lcg_state = lcg_next(lcg_state);
  }
  END_STAGE("5");

  return NULL;
}

int main(int argc, char *argv[]) {
  (void)argc;
  (void)argv;

  debug_print = !!getenv("US_RUNNER_DEBUG");
  private_stdout = fdopen(3, "w");
  if (!private_stdout) {
    private_stdout = stdout;
  }
  private_stderr = fdopen(4, "w");
  if (!private_stderr) {
    private_stderr = stderr;
  }
  setbuf(private_stdout, NULL);
  setbuf(private_stderr, NULL);

  const size_t num_threads = 8;
  pthread_barrier_init(&barrier, NULL, getenv("US_TESTSEQ") ? 1 : num_threads);
  pthread_t *tids = malloc(sizeof(pthread_t *) * num_threads);

  shared_alloc = userswap_alloc(ALLOC_PAGES * PAGE_SIZE);
  if (!shared_alloc || shared_alloc == MAP_FAILED) {
    EPRINT("userswap_alloc failed\n");
    _exit(1);
  }

  if ((size_t)shared_alloc & 0xFFF) {
    EPRINT("userswap_alloc returned non-page-aligned pointer %p\n", shared_alloc);
    _exit(1);
  }

  int filefd = open("/dev/shm", O_TMPFILE | O_RDWR, S_IRUSR | S_IWUSR);
  if (filefd == -1) {
    EPRINT("******* open failed\n");
    _exit(2);
  }

  shared_map = userswap_map(filefd, ALLOC_PAGES * PAGE_SIZE);
  if (!shared_map || shared_map == MAP_FAILED) {
    EPRINT("userswap_map failed\n");
    _exit(1);
  }

  if ((size_t)shared_map & 0xFFF) {
    EPRINT("userswap_map returned non-page-aligned pointer %p\n", shared_map);
    _exit(1);
  }

  if (getenv("US_TESTSEQ")) {
    for (size_t i = 0; i < num_threads; i++) {
      do_test((void *)i);
    }
  } else {
    for (size_t i = 0; i < num_threads; i++) {
      pthread_create(&tids[i], NULL, do_test, (void *)i);
    }

    for (size_t i = 0; i < num_threads; i++) {
      pthread_join(tids[i], NULL);
    }
  }

  return 0;
}
