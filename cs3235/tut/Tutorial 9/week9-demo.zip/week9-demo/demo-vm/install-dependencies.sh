#!/bin/bash
sudo apt update && sudo apt install authbind expect
