// CS4238 Week 10 - A simple example for rundll32.exe
// Complier:
//		Visual C Compiler
// Compilation command:
// 		cl /LD helloworld_dll.c user32.lib /Fehelloworld_dll.dll /link /def:helloworld_dll.def

#include <windows.h>

void CALLBACK func_1 (HWND hWnd, HINSTANCE hInst, LPSTR  lpszCmdLine, int nCmdShow) 
{
  MessageBoxA(0, lpszCmdLine, "func_1 says hello to this world!", 0);
}

void CALLBACK func_2 (HWND hWnd, HINSTANCE hInst, LPSTR  lpszCmdLine, int nCmdShow) 
{
  MessageBoxA(0, lpszCmdLine, "func_2 says hi to this world!", 0);
}