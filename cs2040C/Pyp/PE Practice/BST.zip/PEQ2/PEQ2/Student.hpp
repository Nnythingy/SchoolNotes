#include "Student.h"
#ifndef STUDENTH
#define STUDENTH

#include <iostream>

#pragma once


Student::Student(string name, double cap, int noOfMods) {

	_name = name;
	_cap = cap;
	_noOfModulesTaken = noOfMods;

}
bool Student::operator>(const Student& s) {

	return true;

}

bool Student::operator==(const Student& s) {

	return true;

}

bool Student::operator<(const Student& s) {

	return true;

}

ostream& operator<<(ostream& os, const Student& f)
{
	os << "|| Name: " << f._name << " CAP: " << f._cap << " No Of Modules: " << f._noOfModulesTaken;

	return os;
}


#endif