 
import sys

while True:
  buf = b''
  while not buf.endswith(b'B'):
    buf0 = sys.stdin.buffer.read1(1)
    if len(buf0) == 0:
      sys.exit()
    buf += buf0
  s = int(buf[6:-1])
  while s > 0:
    b = sys.stdin.buffer.read1(s)
    sys.stdout.buffer.write(b)
    sys.stdout.buffer.flush()
    s -= len(b)
