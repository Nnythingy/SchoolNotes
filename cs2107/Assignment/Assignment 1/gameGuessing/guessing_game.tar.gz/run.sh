#!/bin/sh

npm install
node app.js
