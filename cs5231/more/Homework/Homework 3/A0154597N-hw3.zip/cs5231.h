#ifndef _SECURITY_CS5231_H
#define _SECURITY_CS5231_H

/*
 * A demo header file for Linux Security Module: cs5231
 */

#include <uapi/linux/xattr.h>
#include <linux/fs.h>

#endif